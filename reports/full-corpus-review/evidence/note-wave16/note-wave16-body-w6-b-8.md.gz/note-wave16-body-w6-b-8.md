### 법정 정원과 직역 — M.G.L. c.13 §22(a)

Board는 governor가 임명하는 Massachusetts 거주자 13명으로 구성된다. Registered pharmacist 8명, pharmacy technician 1명, 해당 경험을 갖춘 public representative 1명, physician 1명, nurse 1명, patient safety·quality improvement expert 1명이다. 실제 재직자 명단이나 결원 수가 이 법정 정원·직역 배분을 바꾸지는 않는다.

### Pharmacist seat의 setting과 자격 — §22(b)–(i)

Pharmacist 8석은 independent 2, chain 2, hospital 1, LTC pharmacy 1, sterile compounding 1, academic 1로 배분된다. 각 pharmacist member는 최소 7년 연속 pharmacy practice 경험이 있어야 하며 임명·재임명 당시 Commonwealth에서 현재 pharmacy practice에 고용되어 있어야 한다. 각 setting의 추가 요건도 함께 적용한다.

Independent pharmacist의 고용 조직은 Massachusetts 내 registered retail drugstores가 9개 이하이고 full-time pharmacists가 20명 이하이어야 한다. 두 규모 조건을 모두 충족해야 한다. Chain pharmacist는 Massachusetts 내 retail drugstores를 10개 이상 운영하는 등록 조직에 고용된 경로다. 직원 수가 20명을 넘었다는 이유만으로 chain 정의에 자동 편입되는 것은 아니다.

Hospital seat는 Commonwealth 내 hospital setting 7년 경력, LTC seat는 LTC setting 7년 경력을 요구한다. Sterile-compounding seat는 그 practice 7년 경력과 고용 업무의 routine function으로 sterile compounding을 수행하는 조건을 갖추며, academic seat는 Commonwealth가 허가한 고등교육기관의 pharmacy 관련 academic/scholarly position 조건을 따른다. Sterile-compounding member를 §22(i)의 다른 setting 정원에 다시 포함하지 않는다.

### Technician와 징계 이력 — §22(a), (j)–(m)

Technician member는 최소 7년 practical experience가 있고 pharmacy practice를 routine employment function으로 수행해야 한다. §22(k)는 pharmacist와 technician에 대해 임명 전 10년 동안 Board, FDA 또는 DEA의 disciplinary/enforcement action이 없어야 한다고 정한다. §22(m)는 명시된 기관의 면허를 가진 Board member에 대해 해당 licensing board, FDA, DEA action의 10년 조건을 따로 규정한다. Public representative는 §22(l)과 그 조항이 연결한 §9B 요건도 확인한다. §22(a)의 felony 또는 embezzlement·theft·fraud·perjury 관련 범죄로 유죄판결을 받은 사람의 제한도 별도다.

### 임기와 successor를 기다리는 계속 재직 — §22(n)

임기는 3년이며 임명 다음 달의 첫날부터 시작한다. 연속 임기는 2회를 넘을 수 없고, 최대 연속 임기 후 재임명 자격을 얻으려면 적어도 한 임기 동안 재직하지 않아야 한다.

임기가 만료되어도 successor가 임명될 때까지 재직한다. 이 holdover는 세 번째 연속 새 appointment를 허용하는 예외가 아니다. 문제에서 임기 만료, 현재 계속 재직, 새 임기 재임명을 서로 구분한다.