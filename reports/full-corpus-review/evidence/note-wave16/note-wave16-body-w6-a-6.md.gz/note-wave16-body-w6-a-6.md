Dietary supplement: DSHEA 체계 아래 제조·유통업체는 안전성·표시의 적정성을 평가할 책임이 있고, FDA는 adulterated 또는 misbranded 제품에 조치할 수 있다. 일반 의약품의 사전 안전성·유효성 승인 체계를 그대로 적용하지 않는다. 특정 new dietary ingredient에는 별도 notification 요건이 있을 수 있으며, notification를 drug approval이라고 부르지 않는다. 

Cosmetic: 분류는 단순한 매장 위치나 외형보다 intended use에 달려 있다. 미용·세정 목적과 질병 치료·예방 또는 신체 구조·기능에 영향을 주려는 용도를 구별한다. 일반 cosmetic의 사전 승인 체계와 의약품의 승인 체계는 다르며, color additive 등 별도 요건도 있다. ‘FDA-approved cosmetic’이라는 표현을 무비판적으로 받아들이지 않는다. 

Homeopathic: FDA는 현재 homeopathic으로 표시된 승인 제품이 없다고 설명한다. HPUS에 등재되거나 OTC 진열대에 놓였다는 사실은 FDA approval의 증거가 아니다. Homeopathic drug도 approval·adulteration·misbranding 관련 규제에서 자동 면제되는 것이 아니다. 

Medical device: 510(k)는 premarket notification 경로이며 substantial equivalence 판단과 연결된다. 이를 의약품 NDA 승인이나 pharmacist 면허와 동일시하지 않는다. 이 노트는 device 법 전체나 모든 분류별 예외를 다루는 전문 교재가 아니다.