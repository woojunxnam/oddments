미국의 nonprescription drug에는 drug application 경로와 OTC monograph 경로가 있다. NDA 또는 ANDA로 판매승인을 받아 OTC로 공급되는 제품도 있으므로, OTC라는 이유로 모두 개별 승인이 없다고 설명하면 안 된다. 처음부터 nonprescription으로 신청하는 경로와 기존 Rx 제품을 OTC로 전환하는 경로도 구별한다. 

OTC monograph는 해당 범주의 active ingredient, indication, dose, route, labeling, testing 등 일반적으로 안전하고 유효하다고 인정되는 조건을 정한다. FD&C Act §505G와 해당 monograph 및 기타 요구사항을 충족하면 개별 §505 approved application 없이 판매할 수 있다. 이는 FDA 규제가 없다는 뜻이 아니다. 

CARES Act 이후의 §505G 체계는 administrative orders를 사용한다. Proposed order, interim final order, final order의 상태를 확인한다. 공고가 나왔다는 이유만으로 제안된 모든 변경이 시행됐다고 보지 않는다. 오래된 요약의 rulemaking 설명만으로 현재 체계를 끝내지 않는다. 

제품 하나가 OTC로 바뀌어도 동일 성분의 모든 함량·제형·브랜드가 OTC가 되는 것은 아니다. 약사 처방권한, standing order로 보험 청구하는 경로, 소비자의 일반 OTC 구매 경로도 분리한다. 구체적 피임·naloxone 예시는 W5 부록 B에서 확인한다.