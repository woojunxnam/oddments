OPEN-CC — VI 14/30일과 gabapentin/expired 경계. 기본 두 문서와 정책 누락은 이번에 보완했다. 겹치는 사실관계의 통합 적용에는 Board의 명시적 current clarification이 추가로 필요하다. 

OPEN-REPORT — MOR 부재·사임, discipline/criminal, 일부 serious-event의 기한·trigger 차이. [미확정 범위 장](#chapter/open-register)에 양쪽 문구를 유지한다. 하나가 폐지·대체됐다는 공식 근거 또는 동일 사건에 대한 공식 설명 없이는 단일 숫자로 합치지 않는다.

OPEN-ORAL — c.94C §20과 105 CMR 721의 oral follow-up 표현. Federal emergency CII 7일과 주 문구를 분리한다. ‘모든 oral prescription은 한 숫자’로 바꾸는 근거는 확보되지 않았다.

OPEN-COPY — out-of-state CII redacted copy의 현행 제출 channel/PMP 대체 여부. 해당 statutory text는 유지한다. 일반 PMP 제출 안내만으로 대체 충족을 추정하지 않는다.

OPEN-INSTITUTION — LTCF/terminal partial fill의 prescription/order 경계와 bed-tier 일부 경계값. 시설 유형·license·order 종류를 특정한 authority가 필요하며 부등호를 임의 보간하지 않는다.

OPEN-PACK — CII/CIII 금지는 게시 regulation에 남아 있다. Policy의 “unless otherwise prohibited”와 함께 읽어, 생략 자체를 허용으로 해석하지 않는다. 이번 편집 판단은 packaging 장에 별도로 표시했으며 Board의 개별 예외 회신을 확보한 것은 아니다.

OPEN-HIV — Oral PrEP·PEP·STI Tx·DoxyPEP의 statewide DOCX 세부 알고리즘. 공식 index와 파일 존재는 확인했지만 lab·eligibility·initial supply·follow-up 본문은 이번에도 완전히 확보하지 못했다. 다른 주의 protocol 또는 일반 CDC 권고로 MA 권한조건을 대신하지 않는다.

OPEN-PRESCRIBER — Board 시험 참고목록의 BORIM Policy 15-05를 이번 접근 경로에서 완전하게 읽지 못했다. Self/family prescribing의 최신 예외를 임의로 확정한 추가 표는 만들지 않았다. 기존 prescriptive-authority 본문은 유지한다.

OPEN-OTC — MA의 특정 codeine 제품 판매 및 추가 pseudoephedrine/NPLEx·연령 조건. 일반 연방 CMEA 또는 stocking memo가 제품별 주 판매허용의 전부를 증명하지 않는다.

OPEN-DATED — iPLEDGE의 2026-11-15 예정 변경, 2026–27 seasonal vaccine 지시, 임시 telemedicine·DSCSA 적용일. 기존 W3–5의 날짜를 유지하고 시험일에 적용되는 실제 상태를 별도로 확인한다. 이번에 모든 제품·임시제도를 재검증한 것은 아니다.

OPEN-USP — USP 정본 전체, 모든 <825>·allergen·engineering·waste 특수 범위의 독립 전수 검토. 현재 자료는 핵심 framework와 공개 공식 자료 대조이며 구독 정본 전체 검수 완료가 아니다.

이 목록은 모든 법규가 불확실하다는 뜻이 아니다. 확정된 기본 규칙과 추가 증거가 필요한 경계를 분리하여 공부하기 위한 목록이다.

### 2026-10-30 추가 확인 — 기존 목록의 전수 재검증은 아님

**OPEN-CDTM-QUALIFICATION:** [PharmD 자격 설명](#chapter/cdtm/w3-d-2)에 현재 M.G.L. c.112 §24B½(b)(3)의 날짜 없는 PharmD 문구와 247 CMR16.02(1)(c)1의 2017-06-30 CPA 참여 조건을 나란히 기록했다. 두 공식 원문의 적용 관계를 해소할 공식 설명은 확보하지 못했다. 모든 신규 PharmD 지원자의 자격을 일괄 확정하거나 규정 날짜가 폐지됐다고 추정하지 않는다. BPS·residency equivalency 경로는 별도 조건으로 공부한다.

**OPEN-REPORT의 좁은 재확인:** [징계·보고의 구분](#chapter/discipline-inspection/w1-c-14)에서 247 CMR10.03과20.03의 보고 문구 관계를 계속 OPEN으로 표시했다. 이번에 확인한 summary suspension 7 days와 quarantine 15 business days는 [별도 hearing 절차](#chapter/discipline-inspection/w1-c-15)의 숫자이며 보고의무 충돌을 해결하는 숫자가 아니다.

위 두 항목의 상세 공식 링크와 확인 범위는 연결된 절에서 확인한다. 이 등록부의 이전 항목에 새 법규 검증일을 부여한 것은 아니다.