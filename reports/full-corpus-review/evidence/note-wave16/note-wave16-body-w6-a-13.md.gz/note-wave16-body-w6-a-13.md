21 CFR 1301.76(a)는 controlled substances에 접근하는 agent·employee로 고용하는 경우를 다룬다. Controlled substances 관련 felony conviction, DEA registration 신청 거절, 등록 취소, for-cause surrender의 이력을 규정한다. ‘모든 과거 경범죄’ 또는 ‘어떤 약국 직무든 모두 동일’이라고 범위를 바꾸지 않는다. 

For cause는 controlled-substance 취급 조사에서 비롯된 연방·주 administrative, civil, criminal action의 결과 또는 그 대신 이루어진 surrender를 말한다. 단순히 등록을 더 이상 사용하지 않아 자발적으로 종료한 모든 경우와 같다고 추정하지 않는다. 해당 규정의 적용이나 별도 DEA 허용 여부를 확인하지 않은 채 현장 관리자가 임의 예외를 만들 수는 없다. 

이 접근 제한, Massachusetts 개인 면허 상태, OIG exclusion에 따른 federal-program 지급 제한은 세 개의 다른 점검이다. 하나를 통과했다고 나머지가 자동으로 적법한 것은 아니다.