Off-label은 이미 승인된 의약품을 승인된 labeling에 없는 용도 등으로 사용하는 것이다. FDA는 의료인이 medical judgment에 따라 이런 사용을 일반적으로 처방·투여할 수 있다고 설명한다. 그러나 이것이 약사에게 새로운 처방권한을 주거나, controlled-substance 규칙·REMS·주법상 제한을 없애지는 않는다. 

EUA는 특정 비상상황에서 미승인 제품 또는 승인된 제품의 미승인 용도를 허용하는 별도 제도이다. 정식 approval과 증거 기준이 다르고, 승인된 적절한 대안의 가용성 등 법정 조건을 충족해야 한다. 허가된 대상·사용 조건·Fact Sheet와 현재 유효 상태를 확인해야 하며, EUA는 수정·철회될 수 있다. 

Expanded access는 심각하거나 즉각 생명을 위협하는 질환에서 만족할 만한 대안이 없는 경우 등 요구조건 아래 임상시험 밖에서 investigational product에 접근하는 경로이다. 일반 retail prescription 또는 정식 marketing approval과 같지 않다. 

세 제도를 합쳐 ‘FDA가 허용했으니 아무 환자에게나 쓸 수 있다’고 정리하지 않는다. 제품의 승인 상태와 특정 환자에게 적용 가능한 사용 권한은 분리해서 판단한다.