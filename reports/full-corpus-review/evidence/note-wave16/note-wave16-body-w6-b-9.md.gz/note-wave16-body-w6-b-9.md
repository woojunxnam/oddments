c.13 §23은 annual organization과 president·secretary 선출, regular·additional meetings를 규정한다. 조문상 조직 회의는 12월 첫 화요일이며 정기 회의로 1·5·10월 첫 화요일을 명시하고 추가 회의도 허용한다. 실제 최신 Board calendar가 더 많은 회의를 가진다고 조문상의 기본 구조와 모순이라고 단정하지 않는다. 

§25의 agents는 drug stores 및 관련 약·의료품 판매·유통 장소를 점검하고 위반을 Board에 보고하며, Board의 지시에 따라 criminal complaints를 제기한다. §25A는 Board 지시에 따른 USP <795>/<797> 및 추가 sterile/nonsterile surveyor 교육을 다룬다. 검사권한, 최종 징계, criminal complaint, 법원의 유죄 판단은 같은 행위가 아니다. 

이 숫자·조직 항목은 W1의 면허·징계 내용을 보완한다. 실제 처방·상담·기록 규칙보다 무조건 출제 비중이 높다고 주장하지 않는다. 여기서는 §22·23·25·25A를 확인했으며 §24의 독립적인 상세 검토까지 완료한 것으로 표시하지 않는다.