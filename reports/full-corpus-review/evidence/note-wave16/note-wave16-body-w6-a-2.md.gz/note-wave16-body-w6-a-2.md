IND, Investigational New Drug: 임상연구를 위해 investigational drug를 사용할 수 있는 규제 경로이다. FDA의 설명상 주간 운송에 필요한 승인된 marketing application 요건의 면제를 받는 수단이 된다. IND가 있다는 사실은 그 제품을 일반 환자에게 통상적인 처방약처럼 판매할 수 있다는 허가가 아니다. 

NDA, New Drug Application: 새로운 의약품의 안전성·유효성·품질 등을 심사받아 판매승인을 받는 신청이다. 신청서를 제출한 상태와 승인된 상태를 구분한다. 

ANDA, Abbreviated New Drug Application: generic drug의 승인 경로이다. 통상 원개발 제품과 같은 방식으로 광범위한 동물·임상시험을 다시 수행하는 대신 bioequivalence 등을 입증한다. ANDA 승인이 모든 함량·제형·투여경로를 상호교환 가능하게 만든다는 뜻은 아니다. 실제 product selection은 [Label·대체조제 장](#chapter/label-interchange)의 해당 제품·therapeutic equivalence·주법 요건을 적용한다. 

BLA, Biologics License Application: 생물학적 제제의 판매를 위한 허가 신청이다. NDA·ANDA와 이름을 바꾸어 쓰지 않는다. Biological product의 biosimilarity와 interchangeability는 별도 판단이며 [Label·대체조제 장](#chapter/label-interchange)를 연결한다. 

기억할 경계: 연구 허용 ≠ 판매 승인 ≠ 처방권한 ≠ 약국의 대체조제 권한. 각 단계가 서로 다른 질문에 답한다.