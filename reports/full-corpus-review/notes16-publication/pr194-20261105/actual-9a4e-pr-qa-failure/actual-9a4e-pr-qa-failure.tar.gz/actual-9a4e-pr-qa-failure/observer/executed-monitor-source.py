from pathlib import Path
import datetime,hashlib,importlib.util,json,os,re,subprocess,time,urllib.parse
R=Path('/workspace/oddments');BASE=Path('/workspace/scratch/final306-candidate-ci-observations');O=BASE/('monitor-9a4e-'+datetime.datetime.now(datetime.timezone.utc).strftime('%Y%m%dT%H%M%SZ'));O.mkdir();HEAD='9a4e3764aa58ee16435b03a774f092157ff0c3f3';BRANCH='mission/mpje-after193-wave12';REPO='woojunxnam/oddments';H=lambda b:hashlib.sha256(b).hexdigest();now=lambda:datetime.datetime.now(datetime.timezone.utc).isoformat();ENV={k:v for k,v in os.environ.items()if k not in {'GH_DEBUG','DEBUG'}};serial=0;cycle=0
spec=importlib.util.spec_from_file_location('read_only_ci_job_contract',Path('/workspace/scratch/final306_public_verifier.py'));contract=importlib.util.module_from_spec(spec);spec.loader.exec_module(contract)
workflows={};texts={}
for file in contract.QA_FILES:
 raw=subprocess.check_output(['git','show',HEAD+':.github/workflows/'+file],cwd=R);text=raw.decode();name=re.search(r'^name:\s*(.+)$',text,re.M).group(1).strip('"\'');workflows[name]=file;texts[file]=text

def write(path,x):path.parent.mkdir(parents=True,exist_ok=True);path.write_text(json.dumps(x,ensure_ascii=False,indent=2)+'\n')
def api(endpoint,label,json_body=True):
 global serial
 serial+=1;name=f'{serial:05d}-{label}';cmd=['gh','api','--hostname','github.com','--include','--method','GET',endpoint];start=now();p=subprocess.run(cmd,capture_output=True,env=ENV);raw=p.stdout;(O/(name+'.http.raw')).write_bytes(raw);(O/(name+'.stderr.raw')).write_bytes(p.stderr);parts=re.split(b'\r?\n\r?\n',raw,maxsplit=1);statuses=re.findall(rb'^HTTP/\S+\s+(\d+)',raw,re.M);status=int(statuses[-1])if statuses else None;body=parts[1]if len(parts)==2 else b'';(O/(name+'.body.raw')).write_bytes(body);rec={'started_at':start,'completed_at':now(),'argv':cmd,'exit_code':p.returncode,'http_status_codes':[int(x)for x in statuses],'http_status':status,'raw_path':name+'.http.raw','raw_sha256':H(raw),'body_path':name+'.body.raw','body_sha256':H(body),'stderr_path':name+'.stderr.raw','stderr_sha256':H(p.stderr)};write(O/(name+'.receipt.json'),rec)
 if p.returncode or status!=200:raise RuntimeError('Actual API read failed: '+name+' HTTP'+str(status))
 return(json.loads(body)if json_body else body),rec

def logs(run,job):
 name=f'run-{run["id"]}-attempt-{run.get("run_attempt",1)}-job-{job["id"]}';cmd=['gh','run','view',str(run['id']),'--repo',REPO,'--job',str(job['id']),'--log'];start=now();p=subprocess.run(cmd,capture_output=True,env=ENV);path=O/(name+'.log');path.write_bytes(p.stdout);(O/(name+'.stderr.raw')).write_bytes(p.stderr)
 text=p.stdout.decode(errors='replace');matches=[{'line':i+1,'text':line}for i,line in enumerate(text.splitlines())if re.search(r'\b\d+ (?:passed|failed|skipped|errors?)\b.*\bin [\d.]+s',line)];full=[x for x in matches if run['name']=='QA'and job['name']=='validate'and '\tRun tests\t'in x['text']];errors=[{'line':i+1,'text':line}for i,line in enumerate(text.splitlines())if re.search(r'Traceback|ValueError:|AssertionError:|ERROR:|FAILED|##\[error\]',line)]
 rec={'started_at':start,'completed_at':now(),'command':cmd,'exit_code':p.returncode,'log_path':str(path),'raw_log_sha256':H(p.stdout),'stderr_sha256':H(p.stderr),'candidate_sha':HEAD,'run_id':run['id'],'event':run['event'],'workflow':run['name'],'job_id':job['id'],'job_name':job['name'],'actual_pytest_summary_lines':matches,'actual_whole_pytest_Run_tests_summary_lines':full,'whole_pytest_final_count_present':bool(full),'error_lines':errors[-25:]};write(O/(name+'-log-receipt.json'),rec)
 # A separate official HTTP log response preserves real download status/bytes.
 try:raw,proof=api(f'repos/{REPO}/actions/jobs/{job["id"]}/logs',name+'-official-log-download',json_body=False);rec['official_log_download_receipt']=proof
 except Exception as error:rec['official_log_download_error_preserved']=str(error)
 write(O/(name+'-log-receipt-with-http.json'),rec);return rec

known={};job_seen={};downloaded={};announced_failures=set();last_progress=None;terminal_stability=0;previous_ids=set()
print(json.dumps({'phase':'MONITOR_STARTED','directory':str(O),'candidate':HEAD}),flush=True)
for label,endpoint in [('pull194-initial',f'repos/{REPO}/pulls/194'),('main-initial',f'repos/{REPO}/git/ref/heads/main')]:api(endpoint,label)
while True:
 cycle+=1;round_start=now();observed=[]
 try:
  for page in range(1,30):
   endpoint=f'repos/{REPO}/actions/runs?'+urllib.parse.urlencode({'head_sha':HEAD,'per_page':100,'page':page});data,_=api(endpoint,'runs-cycle-'+str(cycle)+'-page-'+str(page));batch=data['workflow_runs'];observed.extend(batch)
   if len(batch)<100:break
  else:raise RuntimeError('Pagination cap reached')
  current=[r for r in observed if r.get('head_sha')==HEAD and r.get('head_branch')==BRANCH]
  for run in current:
   known[run['id']]=run;need_jobs=run['status']!='queued'or run['id']not in job_seen
   if not need_jobs:continue
   payload,_=api(f'repos/{REPO}/actions/runs/{run["id"]}/jobs?per_page=100','jobs-'+str(run['id'])+'-cycle-'+str(cycle));jobs=payload['jobs'];require_pages=payload.get('total_count',len(jobs));
   if require_pages>len(jobs):raise RuntimeError('Unexpected jobs pagination needed; preserve rather than truncate')
   job_seen[run['id']]=jobs
   for job in jobs:
    key=(run['id'],run.get('run_attempt',1),job['id'])
    if job['status']=='completed'and job.get('conclusion')not in {'skipped','neutral'}and key not in downloaded:
     if job['conclusion']=='success'or job['conclusion']in {'failure','timed_out','cancelled','action_required','startup_failure','stale'}:
      downloaded[key]=logs(run,job)
    if job['status']=='completed'and job.get('conclusion')in {'failure','timed_out','cancelled','action_required','startup_failure','stale'}and key not in announced_failures:
     announced_failures.add(key);print(json.dumps({'phase':'ACTUAL_FAILURE','run_id':run['id'],'workflow':run['name'],'event':run['event'],'job_id':job['id'],'job_name':job['name'],'conclusion':job['conclusion'],'log':downloaded.get(key)},ensure_ascii=False),flush=True)
  records=[]
  for run in known.values():
   row={k:run.get(k)for k in ['id','name','head_sha','head_branch','event','status','conclusion','html_url','run_attempt','updated_at']};jobs=job_seen.get(run['id'],[]);row['jobs']=[{k:j.get(k)for k in ['id','name','status','conclusion','started_at','completed_at','html_url']}for j in jobs]
   if run['name']in workflows and run['event']in {'push','pull_request'}:
    try:row['job_contract']=contract.validation_jobs(workflows[run['name']],run['event'],jobs,texts[workflows[run['name']]],allow_pending=run['status']!='completed')
    except Exception as e:row['job_contract']={'status':'FAILED','error':str(e)}
   records.append(row)
  pr=[r for r in records if r['event']=='pull_request'];push=[r for r in records if r['event']=='push'];required={name:[r for r in pr if r['name']==name]for name in workflows};required_success={name for name,rr in required.items()if any(r['status']=='completed'and r['conclusion']=='success'and r.get('job_contract',{}).get('status')=='SUCCESS'for r in rr)}
  progress={'PR_required_success':len(required_success),'PR_required_total':8,'PR_observed_runs':len(pr),'push_success':sum(r['status']=='completed'and r['conclusion']=='success'for r in push),'push_observed_runs':len(push),'terminal_failures':sum(r['status']=='completed'and r['conclusion']!='success'for r in records),'completed':sum(r['status']=='completed'for r in records),'total_runs':len(records),'queued':sum(r['status']=='queued'for r in records),'in_progress':sum(r['status']=='in_progress'for r in records)}
  snapshot={'purpose':'ACTUAL_EXACT_HEAD_CI_MONITOR_READ_ONLY_NO_PUBLIC_VERIFICATION','observed_at':now(),'round_started_at':round_start,'cycle':cycle,'candidate':HEAD,'branch':BRANCH,'progress':progress,'runs':records,'whole_pytest_actual_log_receipts':[x for x in downloaded.values()if x['actual_whole_pytest_Run_tests_summary_lines']],'no_previous_PR193_or1498_results_reused':True,'ROOT_remote_or_native_mutations':0,'cancel_or_rerun_requests':0,'public_site_GET_browser_publisher_execution':0}
  snap=O/f'cycle-{cycle:04d}-summary.json';write(snap,snapshot);write(O/'latest-summary.json',snapshot)
  if progress!=last_progress:print(json.dumps({'phase':'PROGRESS','summary':str(snap),'progress':progress}),flush=True);last_progress=progress
  ids=set(known);all_terminal=bool(known)and all(r['status']=='completed'for r in known.values())and all(required.values())
  terminal_stability=terminal_stability+1 if all_terminal and ids==previous_ids else 0;previous_ids=ids
  if terminal_stability>=1:
   write(O/'final-summary.json',snapshot);write(O/'artifact-sha256.json',{p.name:H(p.read_bytes())for p in O.iterdir()if p.is_file()});print(json.dumps({'phase':'ALL_TERMINAL','summary':str(O/'final-summary.json'),'sha256':H((O/'final-summary.json').read_bytes()),'progress':progress}),flush=True);break
 except Exception as e:
  failure={'observed_at':now(),'cycle':cycle,'error':repr(e),'no_fake_status':'LAST_SUCCESSFUL_OBSERVATION_RETAINED','candidate':HEAD};write(O/f'cycle-{cycle:04d}-observation-error.json',failure);print(json.dumps({'phase':'OBSERVATION_ERROR',**failure}),flush=True)
 time.sleep(30)
