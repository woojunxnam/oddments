#!/usr/bin/env python3
"""Collect final exact-merge main8 + Pages1 + Pages-triggered production2 evidence.

The controller invokes this after deployment. No action occurs on import/help.
This does not run CI, deploy, publish, or perform public-site GET/browser checks.
"""
from __future__ import annotations
import argparse
import base64
from datetime import datetime, timezone
import hashlib
import json
import os
from pathlib import Path
import re
import subprocess
import sys
import time

REPO = 'woojunxnam/oddments'
PUBLIC_READER = Path(__file__).resolve().with_name('final306_public_verifier.py')
PUBLIC_READER_SHA = 'a0e0b737a97289ecd41273c47f7ca02740feb3053087d89023e0432aec184c6d'
CAPTURE_READER = Path(__file__).resolve().with_name('final306_capture_premerge.py')
CAPTURE_READER_SHA = 'abf47ea842ad370006e134a7a2aa90a654ba820448b1cfb34ef5f795f38ec8b8'
PAGES_FILE = 'pages.yml'
PRODUCTION_FILES = ('exam-study-qa.yml', 'representative-quality-qa.yml')
PAGES_NAME = 'Deploy MPJE preview to Pages'
ORIGIN = 'https://woojunxnam.github.io/oddments/'
# Reviewed actual workflow bytes; these are source identities, never past PASS values.
APPROVED_WORKFLOW_SHA256 = {'qa.yml': 'ea042d9a7ed4382f7f9caad17dd3da1dac6b849d4ef3575c315995dbed900c37', 'practice-quality-qa.yml': '0a3b154bbdd36fadd525ad01bfccafcf850d9c76bf33cc8626b5a37dffec650b', 'representative-quality-qa.yml': '76f0971490e1e358a0e4a85e11b29d7a99a20c84f253e25f93d5946f41b876aa', 'notes-qa.yml': '03744682438ea706fabe35c3a0bc1df18dc1d1ad526b1f982892c6439784e087', 'refresh-qa.yml': '9b24e12d2268134505ee75553125d2f2001b4a164d3d75d1e65ab3c5085e3781', 'exam-study-qa.yml': 'cec176dbbd1f2aebef334cd3d7de2583bdcc05696fc8cf7e7547ee2fe2303805', 'public-practice-qa.yml': 'b1a86b05ace247d32bd28d4d605a65cbcf66c600e7f779ec04376f2648330c94', 'practice-expansion-qa.yml': 'eac92af7f5e8f2515525e9ae08584ea469ec1f3eea419ff5ef3b3527e4cfd4ad', 'pages.yml': '790cde60d67dea636ff3a0c86519493f0a3c1dca1213f67fcedb0eb96a0e272f'}


def now(): return datetime.now(timezone.utc).isoformat()
def sha(raw): return hashlib.sha256(raw).hexdigest()
def require(ok, message):
    if not ok: raise ValueError(message)
def full_sha(value):
    if not isinstance(value, str) or not re.fullmatch('[0-9a-f]{40}', value):
        raise argparse.ArgumentTypeError('Require actual lowercase full40 SHA')
    return value
def positive(value):
    try: value = int(value)
    except (TypeError, ValueError): raise argparse.ArgumentTypeError('Require positive integer')
    if value <= 0: raise argparse.ArgumentTypeError('Require positive integer')
    return value
def moment(value):
    require(isinstance(value, str), 'Actual UTC timestamp missing')
    value = datetime.fromisoformat(value.replace('Z', '+00:00'))
    require(value.tzinfo is not None and value.utcoffset().total_seconds() == 0, 'Actual UTC timestamp required')
    return value

def parser():
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument('--candidate-sha', required=True, type=full_sha)
    p.add_argument('--merge-sha', required=True, type=full_sha)
    p.add_argument('--pages-run-id', required=True, type=positive)
    p.add_argument('--output-new-dir', required=True, type=Path)
    return p

def approved_module(path, digest):
    raw = path.read_bytes(); require(sha(raw) == digest, 'Reviewed dependency changed; new source review required')
    namespace = {'__name__': 'postmerge_readonly_dependency', '__file__': str(path)}
    exec(compile(raw, str(path), 'exec'), namespace)
    return namespace

def declared_step_name(step):
    return step.get('name') or ('Run ' + step['uses'] if 'uses' in step else None)

def verify_steps(actual, definition):
    """All source-declared steps must run successfully; no arbitrary skipped steps."""
    expected = [declared_step_name(s) for s in definition['steps']]
    require(all(expected) and len(expected) == len(set(expected)), 'Unsupported duplicate/unnamed source steps')
    require(isinstance(actual, list) and actual, 'Actual step list missing')
    names = [s.get('name') for s in actual]
    require(len(names) == len(set(names)), 'Duplicate actual steps')
    allowed = set(expected) | {'Set up job', 'Complete job'} | {'Post ' + n for n in expected}
    require(set(names) <= allowed and set(expected) <= set(names), 'Missing/unknown actual step')
    require(all(s.get('status') == 'completed' and s.get('conclusion') == 'success' for s in actual),
            'Actual step failed/skipped/incomplete')
    return {'status': 'PASS', 'source_declared_steps': expected, 'actual_steps': names}

def source_contract(filename, text, public):
    require(filename in APPROVED_WORKFLOW_SHA256 and sha(text.encode()) == APPROVED_WORKFLOW_SHA256[filename],
            'Reviewed exact workflow source changed; no deleted/rewritten gate is permitted')
    import yaml
    d = yaml.load(text, Loader=yaml.BaseLoader)
    require(isinstance(d, dict) and isinstance(d.get('jobs'), dict), 'Invalid workflow source')
    if filename != PAGES_FILE:
        public['workflow_jobs_contract'](filename, text)
    else:
        require(d.get('name') == PAGES_NAME and set(d['jobs']) == {'deploy'}, 'Pages source job/name changed')
        require(d.get('on', {}).get('push', {}).get('branches') == ['main'], 'Pages main push source changed')
    if filename in PRODUCTION_FILES:
        trigger = d.get('on', {}).get('workflow_run')
        require(trigger == {'workflows': [PAGES_NAME], 'types': ['completed']},
                'Production must have only the exact Pages completed workflow_run trigger')
        require(set(d.get('on', {})) == {'push', 'pull_request', 'workflow_run'},
                'Unexpected production workflow trigger')
        job = d['jobs']['production']
        require(job.get('if') == public['PRODUCTION_IF'], 'Exact production IF changed')
        checkout = [s for s in job['steps'] if s.get('uses', '').startswith('actions/checkout@')]
        require(len(checkout) == 1 and checkout[0].get('with') == {'ref': '${{ github.event.workflow_run.head_sha }}'},
                'Production checkout is not exact triggering workflow head_sha')
        if filename == 'exam-study-qa.yml':
            selected = [s for s in job['steps'] if s.get('run') == 'python scripts/verify_exam_study_production.py']
            require(len(selected) == 1 and selected[0].get('env') == {'EXPECTED_SHA': '${{ github.event.workflow_run.head_sha }}'},
                    'Study EXPECTED_SHA must be exact triggering workflow head_sha')
        else:
            command = next((s.get('run', '') for s in job['steps'] if s.get('name') == 'Exercise the deployed Pages version and persistent origin'), '')
            require('python scripts/verify_representative_rewrites.py --base-url ' + ORIGIN in command,
                    'Representative actual-origin production command missing')
    return d

def matching_run(run, filename, event, merge):
    return (run.get('path') == '.github/workflows/' + filename and run.get('event') == event
            and run.get('head_sha') == merge and run.get('head_branch') == 'main')

def latest_run(runs):
    return max(runs, key=lambda r: (moment(r['created_at']), int(r['id']), int(r.get('run_attempt', 1)))) if runs else None

def run_identity(run):
    if run is None: return None
    return {k: run.get(k) for k in ('id', 'run_attempt', 'head_sha', 'head_branch', 'path', 'event', 'status', 'conclusion', 'updated_at')}

def log_proof(raw, merge, filename):
    """Verify actual checkout command output, not merely a SHA mentioned somewhere."""
    text = raw.decode('utf-8', errors='strict')
    text = re.sub(r'\x1b\[[0-9;]*m', '', text)
    # gh run view prefixes each original timestamp with job/step tab labels.
    lines = [re.sub(r'^\d{4}-\d\d-\d\dT\S+\s+', '', re.sub(r'^[^\t\r\n]+\t[^\t\r\n]+\t', '', x)).strip() for x in text.splitlines()]
    refs = [x.split(':', 1)[1].strip() for x in lines if re.match(r'^ref:\s*[0-9a-f]{40}$', x)]
    require(refs and set(refs) == {merge}, 'Production checkout input ref differs from exact merge')
    actual = []
    for i, line in enumerate(lines):
        if re.search(r'(?:^|/)git log -1 --format=%H(?:\s|$)', line):
            for value in lines[i + 1:i + 5]:
                if re.fullmatch('[0-9a-f]{40}', value): actual.append(value); break
    require(actual and set(actual) == {merge}, 'Production git log actual HEAD missing/mismatched')
    if filename == 'exam-study-qa.yml':
        values = [x.split(':', 1)[1].strip() for x in lines if x.startswith('EXPECTED_SHA:')]
        require(values and set(values) == {merge}, 'Actual study EXPECTED_SHA missing/mismatched')
        require('Production exam-study assets match the merged source byte-for-byte.' in text
                and 'Production full-note content, manifest, HTML and Markdown exports match the merged source byte-for-byte.' in text,
                'Actual study production verification output missing')
    else:
        require('python scripts/verify_representative_rewrites.py --base-url ' + ORIGIN in text
                and 'every new case (77) passes wrong/correct grading, shuffled-letter mapping, exact citation links and 320px layout' in text
                and 'backup/import keeps all old and revised attempts under their own IDs' in text
                and 'no uncaught JavaScript errors' in text,
                'Actual representative production command/completion output missing')
    return {'status': 'PASS', 'actual_checkout_ref': merge, 'actual_git_log_HEAD': merge,
            'actual_EXPECTED_SHA': merge if filename == 'exam-study-qa.yml' else None,
            'raw_log_sha256': sha(raw)}

class Collector:
    def __init__(self, a):
        self.a = a; self.out = a.output_new_dir.resolve(); self.created = False; self.counter = 0
        self.public = approved_module(PUBLIC_READER, PUBLIC_READER_SHA)
        self.capture = approved_module(CAPTURE_READER, CAPTURE_READER_SHA)
        self.env = self.capture['clean_api_environment'](os.environ)
        self.self_sha = sha(Path(__file__).read_bytes()); self.started = now(); self.tick = time.monotonic()
        require(not self.out.exists(), 'Output already exists; never overwrite observations')
        require(not any((p / '.git').exists() for p in self.out.parents), 'External output outside every Git checkout required')
        self.sources = {}; self.definitions = {}; self.rows = []
    def write(self, path, raw):
        p = self.out / path; p.parent.mkdir(parents=True, exist_ok=True, mode=0o700)
        with p.open('xb') as f: f.write(raw)
    def json(self, path, data): self.write(path, (json.dumps(data, ensure_ascii=False, indent=2) + '\n').encode())
    def request(self, endpoint, label, is_log=False):
        require(endpoint.startswith('repos/' + REPO + '/') and '#' not in endpoint, 'Official fixed repository API only')
        self.counter += 1; prefix = 'api/' + str(self.counter).zfill(3) + '-' + label
        cmd = ['gh', 'api', '--hostname', 'github.com', '--include', '--method', 'GET', endpoint]
        start = now(); tick = time.monotonic()
        try:
            p = subprocess.run(cmd, capture_output=True, env=self.env, timeout=60, check=False)
            stdout, stderr, code = p.stdout, p.stderr, p.returncode
        except subprocess.TimeoutExpired as e: stdout, stderr, code = e.stdout or b'', e.stderr or b'', None
        # Signed redirect URLs must never be printed or committed. Retain raw log
        # body unchanged; only secret-bearing HTTP header values are redacted.
        parts = re.split(rb'\r?\n\r?\n', stdout, maxsplit=1)
        headers = parts[0] if len(parts) == 2 else b''; body = parts[1] if len(parts) == 2 else stdout
        redacted = re.sub(rb'(?im)^(location|authorization|proxy-authorization|set-cookie):[^\r\n]*', rb'\1: [REDACTED_HEADER_VALUE]', headers)
        self.write(prefix + '.headers.redacted.raw', redacted)
        secret = bool(re.search(rb'(?:gh[opsu]_[A-Za-z0-9]{20,}|github_pat_[A-Za-z0-9_]{20,}|[?&]sig=[^\s&]+)', body))
        if not secret: self.write(prefix + ('.log.raw' if is_log else '.response.raw.json'), body)
        match = re.match(rb'^HTTP/\S+\s+([0-9]{3})(?:\s|$)', headers); status = int(match.group(1)) if match else None
        receipt = {'started_at_utc': start, 'retrieved_at_utc': now(), 'wall_seconds': time.monotonic() - tick,
                   'command': cmd, 'official_url': 'https://api.github.com/' + endpoint, 'exit_code': code,
                   'http_status': status, 'tls_verified': code == 0 and status == 200,
                   'TLS_basis': 'Official gh HTTPS default validation; alternate host/socket/insecure options forbidden',
                   'raw_http_sha256': sha(stdout), 'raw_headers_sha256': sha(headers), 'redacted_headers_sha256': sha(redacted),
                   'raw_body_sha256': sha(body), 'body_retained': not secret, 'secretlike_body_blocked': secret,
                   'stderr_sha256': sha(stderr), 'stderr_bytes': len(stderr), 'stderr_content_retained': False}
        self.json(prefix + '.receipt.json', receipt)
        require(not secret, 'SOURCE_BLOCKED: secret-like log/response content was not retained')
        require(code == 0 and status == 200, 'SOURCE_BLOCKED: actual API/log request unsuccessful: ' + label)
        if is_log: return body, receipt
        data = json.loads(body); require(isinstance(data, (dict, list)), 'Actual API JSON shape invalid'); return data
    def paged(self, endpoint, key, label):
        rows = []
        for page in range(1, 101):
            d = self.request(endpoint + ('&' if '?' in endpoint else '?') + 'per_page=100&page=' + str(page), label + '-' + str(page))
            batch = d[key] if key else d; require(isinstance(batch, list), 'API pagination shape invalid'); rows.extend(batch)
            if len(batch) < 100: return rows
        raise ValueError('SOURCE_BLOCKED: pagination incomplete')
    def source(self, filename):
        data = self.request('repos/' + REPO + '/contents/.github/workflows/' + filename + '?ref=' + self.a.merge_sha, 'source-' + filename)
        require(data.get('encoding') == 'base64' and data.get('path') == '.github/workflows/' + filename, 'Workflow content binding invalid')
        raw = base64.b64decode(re.sub(r'\s+', '', data['content']), validate=True)
        require(hashlib.sha1(b'blob ' + str(len(raw)).encode() + b'\0' + raw).hexdigest() == data.get('sha'), 'Workflow Git blob differs')
        self.write('workflow-sources/' + filename, raw); self.sources[filename] = sha(raw)
        self.definitions[filename] = source_contract(filename, raw.decode(), self.public)
    def jobs(self, run):
        require(run.get('repository', {}).get('full_name') == REPO, 'Actual run repository mismatch')
        return self.paged('repos/' + REPO + '/actions/runs/' + str(run['id']) + '/jobs', 'jobs', 'jobs-' + str(run['id']))
    def main_row(self, filename, run):
        if run is None: return {'workflow': filename, 'status': 'MISSING'}
        require(matching_run(run, filename, 'push', self.a.merge_sha), 'Main workflow head/event/branch mismatch')
        require(run.get('name') == self.definitions[filename]['name'], 'Main workflow source name mismatch')
        jobs = self.jobs(run); row = {'workflow': filename, 'run': run_identity(run), 'status': 'PENDING', 'jobs': jobs}
        try:
            check = self.public['validation_jobs'](filename, 'push', jobs, (self.out / 'workflow-sources' / filename).read_text(), allow_pending=run['status'] != 'completed')
            row['validation_job_check'] = check
            if run['status'] == 'completed':
                require(run.get('conclusion') == 'success' and check['status'] == 'SUCCESS', 'Main validation run failed/incomplete')
                for job in jobs:
                    if job['name'] != 'production': verify_steps(job.get('steps'), self.definitions[filename]['jobs'][job['name']])
                row['status'] = 'PASS'
        except (ValueError, KeyError) as e: row.update(status='FAILED', error=str(e))
        return row
    def pages(self, run):
        require(run.get('id') == self.a.pages_run_id and matching_run(run, PAGES_FILE, 'push', self.a.merge_sha), 'Pages exact run/head/main/push mismatch')
        require(run.get('name') == PAGES_NAME, 'Actual Pages workflow name mismatch')
        jobs = self.jobs(run); row = {'workflow': PAGES_FILE, 'run': run_identity(run), 'jobs': jobs, 'status': 'PENDING'}
        if run.get('status') != 'completed': return row
        try:
            require(run.get('conclusion') == 'success' and len(jobs) == 1 and jobs[0].get('name') == 'deploy', 'Pages run/deploy failed or missing')
            require(jobs[0].get('status') == 'completed' and jobs[0].get('conclusion') == 'success', 'Pages deployment job failed')
            verify_steps(jobs[0].get('steps'), self.definitions[PAGES_FILE]['jobs']['deploy'])
            row.update(status='PASS', completed_at_utc=jobs[0]['completed_at']); moment(row['completed_at_utc'])
        except (ValueError, KeyError) as e: row.update(status='FAILED', error=str(e))
        return row
    def production_row(self, filename, run, page):
        if run is None: return {'workflow': filename, 'status': 'MISSING'}
        require(matching_run(run, filename, 'workflow_run', self.a.merge_sha), 'Production exact head/main/workflow_run mismatch')
        row = {'workflow': filename, 'run': run_identity(run), 'status': 'PENDING'}
        if page['status'] != 'PASS': row['blocked_by_pages'] = page['status']; return row
        require(run.get('name') == self.definitions[filename]['name'], 'Production source name mismatch')
        if moment(run['created_at']) < moment(page['completed_at_utc']):
            row.update(status='MISSING', reason='No fresh production trigger after selected Pages completion; older run not reused')
            return row
        if isinstance(run.get('workflow_run'), dict) and 'id' in run['workflow_run']:
            require(run['workflow_run']['id'] == self.a.pages_run_id, 'Actual parent Pages run ID differs')
            row['explicit_parent_run_id'] = self.a.pages_run_id
        else: row['explicit_parent_run_id'] = None
        row['trigger_evidence_basis'] = 'SOLE_SOURCE_PAGES_COMPLETED_TRIGGER_EXACT_HEAD_MAIN_CREATED_AFTER_SUCCESSFUL_SELECTED_PAGES_PLUS_ACTUAL_CHECKOUT_LOG'
        row['parent_id_API_limitation'] = 'Parent ID not invented when Actions run API omits webhook workflow_run payload; exact constraints and actual checkout prove source head, not a fabricated parent identifier.'
        jobs = self.jobs(run); row['jobs'] = jobs
        if run.get('status') != 'completed': return row
        try:
            require(run.get('conclusion') == 'success', 'Production run failed')
            expected = set(self.definitions[filename]['jobs']); require({j.get('name') for j in jobs} == expected and len(jobs) == len(expected), 'Production jobs missing/duplicate/unknown')
            production = next(j for j in jobs if j['name'] == 'production')
            for job in jobs:
                require(job['status'] == 'completed', 'Production job incomplete')
                require(job['conclusion'] == ('success' if job['name'] == 'production' else 'skipped'), 'Production/false-if validation job result invalid')
                if job['name'] != 'production': require(not job.get('steps'), 'False-if validation job unexpectedly executed steps')
            verify_steps(production.get('steps'), self.definitions[filename]['jobs']['production'])
            raw, receipt = self.production_log(production['id'])
            row['actual_log_proof'] = log_proof(raw, self.a.merge_sha, filename); row['actual_log_receipt'] = receipt; row['status'] = 'PASS'
        except (ValueError, KeyError, UnicodeError) as e:
            row.update(status='SOURCE_BLOCKED' if str(e).startswith('SOURCE_BLOCKED:') else 'FAILED', error=str(e))
        return row
    def production_log(self, job_id):
        try:
            return self.request('repos/' + REPO + '/actions/jobs/' + str(job_id) + '/logs',
                                'production-log-' + str(job_id), is_log=True)
        except ValueError as error:
            require(str(error).startswith('SOURCE_BLOCKED:'), 'Unexpected direct log failure')
            direct_failure = str(error)
        # Actual supported GitHub CLI transport; never relabel CLI exit0 as HTTP200.
        cmd = ['gh', 'run', 'view', '--repo', REPO, '--job', str(job_id), '--log']
        started = now(); tick = time.monotonic()
        try:
            process = subprocess.run(cmd, capture_output=True, env=self.env, timeout=60, check=False)
            stdout, stderr, code = process.stdout, process.stderr, process.returncode
        except subprocess.TimeoutExpired as error:
            stdout, stderr, code = error.stdout or b'', error.stderr or b'', None
        secret = bool(re.search(rb'(?:gh[opsu]_[A-Za-z0-9]{20,}|github_pat_[A-Za-z0-9_]{20,}|[?&]sig=[^\s&]+)', stdout))
        path = 'logs/production-job-' + str(job_id) + '.gh-run-view.raw.log'
        if not secret: self.write(path, stdout)
        receipt = {'started_at_utc': started, 'retrieved_at_utc': now(),
                   'wall_seconds': time.monotonic() - tick, 'command': cmd,
                   'official_repository': REPO, 'actual_job_id': job_id,
                   'job_binding_basis': 'Exact completed production job from retained exact-run jobs API response',
                   'direct_API_failure_preserved': direct_failure, 'actual_exit_code': code,
                   'HTTP_status': None, 'HTTP_status_observable': False,
                   'default_verified_HTTPS_via_official_gh': True,
                   'stdout_sha256': sha(stdout), 'stdout_bytes': len(stdout),
                   'raw_log_path': path if not secret else None,
                   'secretlike_stdout_blocked': secret, 'stderr_sha256': sha(stderr),
                   'stderr_bytes': len(stderr), 'stderr_content_retained': False,
                   'credentials_or_signed_redirect_URL_logged': False}
        self.json('logs/production-job-' + str(job_id) + '.gh-run-view.receipt.json', receipt)
        require(not secret and code == 0 and bool(stdout), 'SOURCE_BLOCKED: both direct API and actual CLI job log retrieval failed')
        return stdout, receipt

    def inventory(self, label):
        main = self.request('repos/' + REPO + '/git/ref/heads/main', label + '-main')
        require(main.get('ref') == 'refs/heads/main' and main.get('object', {}).get('sha') == self.a.merge_sha, 'Actual latest main moved')
        runs = self.paged('repos/' + REPO + '/actions/runs?head_sha=' + self.a.merge_sha, 'workflow_runs', label + '-runs')
        chosen = {}
        for filename in self.public['QA_FILES']:
            chosen[filename] = latest_run([x for x in runs if matching_run(x, filename, 'push', self.a.merge_sha)])
        page_runs = [x for x in runs if matching_run(x, PAGES_FILE, 'push', self.a.merge_sha)]
        newest_page = latest_run(page_runs)
        require(newest_page is not None and newest_page['id'] == self.a.pages_run_id, 'Selected Pages is not latest exact-merge main push deployment')
        for filename in PRODUCTION_FILES:
            chosen['production:' + filename] = latest_run([x for x in runs if matching_run(x, filename, 'workflow_run', self.a.merge_sha)])
        chosen['Pages'] = newest_page
        return chosen
    def finish(self):
        self.json('artifact-sha256.json', {p.relative_to(self.out).as_posix(): sha(p.read_bytes()) for p in sorted(self.out.rglob('*')) if p.is_file() and p.name != 'artifact-sha256.json'})
    def run(self):
        self.out.mkdir(parents=True, exist_ok=False, mode=0o700); self.created = True
        self.write('executed-collector-source.py', Path(__file__).read_bytes())
        self.json('inputs.json', {'candidate_sha': self.a.candidate_sha, 'merge_sha': self.a.merge_sha, 'pages_run_id': self.a.pages_run_id,
                  'helper_sha256': self.self_sha, 'reused_public_verifier_sha256': PUBLIC_READER_SHA, 'reused_capture_environment_sha256': CAPTURE_READER_SHA,
                  'status': 'COLLECTING_NOT_PASS', 'new_QA_or_legal_release_credit': 0})
        candidate = self.request('repos/' + REPO + '/git/commits/' + self.a.candidate_sha, 'candidate-commit')
        merge = self.request('repos/' + REPO + '/git/commits/' + self.a.merge_sha, 'merge-commit')
        require(candidate.get('sha') == self.a.candidate_sha and merge.get('sha') == self.a.merge_sha
                and candidate.get('tree', {}).get('sha') == merge.get('tree', {}).get('sha'), 'Actual tested/merged commit trees differ')
        tree = full_sha(candidate['tree']['sha'])
        for filename in (*self.public['QA_FILES'], PAGES_FILE): self.source(filename)
        initial = self.inventory('initial')
        page_run = self.request('repos/' + REPO + '/actions/runs/' + str(self.a.pages_run_id), 'exact-pages-run')
        page = self.pages(page_run); self.rows.append(page)
        for filename in self.public['QA_FILES']: self.rows.append(self.main_row(filename, initial[filename]))
        for filename in PRODUCTION_FILES: self.rows.append(self.production_row(filename, initial['production:' + filename], page))
        final = self.inventory('final')
        stable = {k: run_identity(v) for k, v in initial.items()} == {k: run_identity(v) for k, v in final.items()}
        self.json('latest-stability.json', {'initial': {k: run_identity(v) for k, v in initial.items()}, 'final': {k: run_identity(v) for k, v in final.items()}, 'same_latest_runs_and_states': stable})
        require(sha(Path(__file__).read_bytes()) == self.self_sha and sha(PUBLIC_READER.read_bytes()) == PUBLIC_READER_SHA and sha(CAPTURE_READER.read_bytes()) == CAPTURE_READER_SHA, 'Reviewed helper dependencies changed')
        states = [r['status'] for r in self.rows]
        status = 'UNSTABLE' if not stable else 'FAILED' if 'FAILED' in states else 'SOURCE_BLOCKED' if 'SOURCE_BLOCKED' in states else 'MISSING' if 'MISSING' in states else 'PENDING' if 'PENDING' in states else 'PASS'
        require(len(self.rows) == 11, 'Incomplete main9 plus production2 inventory')
        observation = {'observed_at_utc': now(), 'started_at_utc': self.started, 'wall_seconds': time.monotonic() - self.tick,
                       'candidate_sha': self.a.candidate_sha, 'merge_sha': self.a.merge_sha, 'tree': tree, 'pages_run_id': self.a.pages_run_id,
                       'status': status, 'all_main9_and_production2_completed_successfully': status == 'PASS',
                       'main8_count': 8, 'Pages_count': 1, 'production_count': 2, 'results': self.rows,
                       'new_legal_or_canonical_release_credit': 0,
                       'SOURCE_BLOCKED_scope': 'Software evidence retrieval or validation limitation only; never a legal SOURCE_BLOCKED grade or question disposition',
                       'public_assets_or_browser_verification_performed': False,
                       'requires_separate_actual_public40_and_browser5_verification': True}
        self.json('completion-proof.json', observation); self.finish(); return status

def main(argv=None):
    a = parser().parse_args(argv); collector = None
    try:
        collector = Collector(a); status = collector.run()
        print(json.dumps({'status': status, 'all_main9_and_production2_success': status == 'PASS', 'proof': str(collector.out / 'completion-proof.json')}))
        return 0 if status == 'PASS' else 1 if status in {'FAILED', 'SOURCE_BLOCKED'} else 2
    except Exception as e:
        if collector is not None and collector.created:
            collector.json('failure.json', {'observed_at_utc': now(), 'status': 'FAILED_NO_PASS', 'error_type': type(e).__name__, 'error': str(e), 'collected_rows': collector.rows, 'all_main9_and_production2_success': False, 'SOURCE_BLOCKED_scope': 'Software evidence limitation only, not legal review status'})
            collector.finish()
        print('POSTMERGE COLLECTION FAILED: ' + type(e).__name__ + ': ' + str(e), file=sys.stderr); return 1

if __name__ == '__main__': raise SystemExit(main())
