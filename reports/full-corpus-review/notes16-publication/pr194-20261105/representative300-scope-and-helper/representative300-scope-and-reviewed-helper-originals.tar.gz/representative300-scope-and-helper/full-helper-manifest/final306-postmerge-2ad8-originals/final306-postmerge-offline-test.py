from pathlib import Path
import ast,base64,copy,datetime,hashlib,json,subprocess,sys,tempfile,types
# Deny every real subprocess and network transport before importing helper code.
import socket,urllib.request,http.client,os
DENIED=[]
def DENY(*a,**k):
 DENIED.append('unmocked_external_operation');raise AssertionError('OFFLINE DENY: unexpected external operation')
for attr in ('run','Popen','check_output','call','check_call'):setattr(subprocess,attr,DENY)
socket.create_connection=DENY;socket.socket.connect=DENY;socket.socket.connect_ex=DENY
socket.getaddrinfo=DENY;socket.gethostbyname=DENY;socket.gethostbyname_ex=DENY
os.system=DENY;os.popen=DENY
urllib.request.urlopen=DENY;urllib.request.urlretrieve=DENY
http.client.HTTPConnection.connect=DENY;http.client.HTTPSConnection.connect=DENY
try:
 import requests
 requests.sessions.Session.request=DENY
except ImportError:pass
try:
 import httpx
 httpx.Client.request=DENY;httpx.AsyncClient.request=DENY
except ImportError:pass
P=Path('/workspace/scratch/final306_collect_postmerge.py');RAW=P.read_bytes();N={'__name__':'offline_only','__file__':str(P)};exec(compile(ast.parse(RAW),str(P),'exec'),N)
R=Path('/workspace/oddments');PUB=N['approved_module'](N['PUBLIC_READER'],N['PUBLIC_READER_SHA']);SRC={f:(R/'.github/workflows'/f).read_bytes()for f in(*PUB['QA_FILES'],'pages.yml')};D={f:N['source_contract'](f,b.decode(),PUB)for f,b in SRC.items()};C='1'*40;M='2'*40;T='3'*40;REPO=N['REPO'];CASES=[]
def steps(d):return [{'name':'Set up job','status':'completed','conclusion':'success'}]+[{'name':N['declared_step_name'](s),'status':'completed','conclusion':'success'}for s in d['steps']]+[{'name':'Complete job','status':'completed','conclusion':'success'}]
def log(f):
 s='2026-11-05T00:12:00.000Z ref: '+M+'\n2026-11-05T00:12:01.000Z [command]/usr/bin/git log -1 --format=%H\n2026-11-05T00:12:01.000Z '+M+'\n'
 if f=='exam-study-qa.yml':s+='EXPECTED_SHA: '+M+'\nProduction exam-study assets match the merged source byte-for-byte.\nProduction full-note content, manifest, HTML and Markdown exports match the merged source byte-for-byte.\n'
 else:s+='python scripts/verify_representative_rewrites.py --base-url '+N['ORIGIN']+'\nevery new case (77) passes wrong/correct grading, shuffled-letter mapping, exact citation links and 320px layout\nbackup/import keeps all old and revised attempts under their own IDs\nno uncaught JavaScript errors\n'
 return s.encode()
def fixture(mode):
 runs=[];jobs={};files={}
 for i,f in enumerate((*PUB['QA_FILES'],'pages.yml',*N['PRODUCTION_FILES'])):
  prod=i>=9;rid=900 if i==8 else 901+i-9 if prod else 100+i
  run={'id':rid,'run_attempt':1,'head_sha':M,'head_branch':'main','path':'.github/workflows/'+f,'event':'workflow_run'if prod else'push','name':D[f]['name'],'status':'completed','conclusion':'success','created_at':'2026-11-05T00:11:00Z'if prod else'2026-11-05T00:01:00Z','updated_at':'2026-11-05T00:12:00Z','repository':{'full_name':REPO}}
  runs.append(run);files[rid]=f;jobs[rid]=[]
  for name,definition in D[f]['jobs'].items():
   skipped=(name!='production')if prod else(name=='production')
   jobs[rid].append({'id':rid*10+len(jobs[rid]),'name':name,'status':'completed','conclusion':'skipped'if skipped else'success','steps':[]if skipped else steps(definition),'completed_at':'2026-11-05T00:10:00Z'})
 def rr(i):return next(r for r in runs if r['id']==i)
 if mode=='missing':runs.remove(rr(100))
 if mode=='pending':rr(100).update(status='in_progress',conclusion=None);jobs[100][0].update(status='in_progress',conclusion=None)
 if mode=='failed':rr(100)['conclusion']='failure'
 if mode=='requiredskip':jobs[100][0]['conclusion']='skipped'
 if mode=='stepskip':jobs[100][0]['steps'][1]['conclusion']='skipped'
 if mode=='unknownjob':jobs[100].append({'name':'unknown'})
 if mode=='pagesfail':rr(900)['conclusion']='failure'
 if mode=='pagespending':rr(900).update(status='in_progress',conclusion=None)
 if mode=='prodmissing':runs.remove(rr(901))
 if mode=='prodpending':rr(901).update(status='in_progress',conclusion=None)
 if mode=='prodfail':rr(901)['conclusion']='failure'
 if mode=='oldprod':rr(901)['created_at']='2026-11-05T00:09:00Z'
 if mode=='prodothersuccess':jobs[901][0]['conclusion']='success'
 if mode=='prodstepskip':next(j for j in jobs[901]if j['name']=='production')['steps'][1]['conclusion']='skipped'
 if mode=='prodwrongbranch':rr(901)['head_branch']='other'
 def request(self,e,label,is_log=False):
  if '/contents/'in e:
   f=e.split('/contents/.github/workflows/')[1].split('?')[0];b=SRC[f];return {'encoding':'base64','path':'.github/workflows/'+f,'content':base64.b64encode(b).decode(),'sha':hashlib.sha1(b'blob '+str(len(b)).encode()+b'\0'+b).hexdigest()}
  if '/git/commits/'in e:return {'sha':C if e.endswith(C)else M,'tree':{'sha':T}}
  if e.endswith('/git/ref/heads/main'):return {'ref':'refs/heads/main','object':{'sha':M}}
  if '/actions/runs?head_sha='in e:
   value=copy.deepcopy(runs)
   if mode=='unstable'and label.startswith('final-'):value[0]['run_attempt']=2
   return {'workflow_runs':value}
  if e.endswith('/actions/runs/900'):return rr(900)
  if '/actions/runs/'in e and'/jobs?'in e:return {'jobs':jobs[int(e.split('/actions/runs/')[1].split('/')[0])]}
  if '/actions/jobs/'in e:
   if mode=='blocked':raise ValueError('SOURCE_BLOCKED: synthetic transport denial')
   b=log(files[int(e.split('/actions/jobs/')[1].split('/')[0])//10])
   if mode=='wronglog':b=b.replace(b'git log -1 --format=%H',b'git status')
   if mode=='wrongexpected':b=b.replace(('EXPECTED_SHA: '+M).encode(),b'EXPECTED_SHA: wrong')
   return b,{'http_status':200,'tls_verified':True,'synthetic_only':True}
  raise AssertionError('Unexpected mock endpoint '+e)
 return request
original=N['Collector'].request
for mode,wanted in {'success':'PASS','missing':'MISSING','pending':'PENDING','failed':'FAILED','requiredskip':'FAILED','stepskip':'FAILED','unknownjob':'FAILED','pagesfail':'FAILED','pagespending':'PENDING','prodmissing':'MISSING','prodpending':'PENDING','prodfail':'FAILED','oldprod':'MISSING','prodothersuccess':'FAILED','prodstepskip':'FAILED','prodwrongbranch':'MISSING','wronglog':'FAILED','wrongexpected':'FAILED','blocked':'SOURCE_BLOCKED','unstable':'UNSTABLE'}.items():
 N['Collector'].request=fixture(mode)
 def MOCK_FALLBACK(cmd,**kw):
  assert mode=='blocked' and cmd[:6]==['gh','run','view','--repo',REPO,'--job'] and cmd[6] in {'9011','9021'} and cmd[7:]==['--log']
  return types.SimpleNamespace(stdout=b'',stderr=b'SYNTHETIC-BLOCKED',returncode=1)
 subprocess.run=MOCK_FALLBACK
 with tempfile.TemporaryDirectory(prefix='SYNTHETIC-ONLY-postmerge-',dir='/workspace/scratch')as tmp:
  v=N['Collector'](types.SimpleNamespace(candidate_sha=C,merge_sha=M,pages_run_id=900,output_new_dir=Path(tmp)/'new'));actual=v.run();assert actual==wanted,(mode,actual,wanted);d=json.loads((v.out/'completion-proof.json').read_bytes());assert len(d['results'])==11 and d['all_main9_and_production2_completed_successfully']==(wanted=='PASS')
 CASES.append({'case':mode,'expected':wanted,'actual':actual,'result':'EXPECTED_OFFLINE_RESULT'})
N['Collector'].request=original
subprocess.run=DENY
def reject(label,fn):
 try:fn()
 except (ValueError,KeyError,UnicodeError)as e:CASES.append({'case':label,'result':'EXPECTED_REJECTION','error':str(e)});return
 raise AssertionError('Accepted mutation '+label)
for f in N['PRODUCTION_FILES']:
 text=SRC[f].decode()
 reject(f+' wrongtrigger',lambda f=f,text=text:N['source_contract'](f,text.replace("workflows: ['Deploy MPJE preview to Pages']","workflows: ['Other']"),PUB))
 reject(f+' wrongcheckout',lambda f=f,text=text:N['source_contract'](f,text.replace('${{ github.event.workflow_run.head_sha }}','${{ github.sha }}'),PUB))
 reject(f+' wrongIF',lambda f=f,text=text:N['source_contract'](f,text.replace(PUB['PRODUCTION_IF'],"github.event_name == 'push'"),PUB))
 reject(f+' unknownsteps',lambda f=f:N['verify_steps']([{'name':'unknown','status':'completed','conclusion':'skipped'}],D[f]['jobs']['production']))
reject('missing EXPECTED_SHA source',lambda:N['source_contract']('exam-study-qa.yml',SRC['exam-study-qa.yml'].decode().replace('EXPECTED_SHA:','OTHER_VARIABLE:'),PUB))
for f in N['PRODUCTION_FILES']:assert N['log_proof'](log(f),M,f)['status']=='PASS'
saved=subprocess.run
with tempfile.TemporaryDirectory(prefix='SYNTHETIC-ONLY-postmerge-transport-',dir='/workspace/scratch')as tmp:
 v=N['Collector'](types.SimpleNamespace(candidate_sha=C,merge_sha=M,pages_run_id=900,output_new_dir=Path(tmp)/'new'));v.out.mkdir();v.created=True
 try:
  def fake(cmd,**kw):
   assert cmd[:7]==['gh','api','--hostname','github.com','--include','--method','GET'];assert not any(k in kw['env']for k in ['GH_DEBUG','DEBUG']);return types.SimpleNamespace(stdout=b'HTTP/2.0 200 OK\r\nLocation: https://example.invalid/?sig=NEVER-PERSIST\r\n\r\n{"value":1}',stderr=b'SYNTHETIC-CREDENTIAL-NEVER-PERSIST',returncode=0)
  subprocess.run=fake;assert v.request('repos/'+REPO+'/test','mock200')=={'value':1};assert b'NEVER-PERSIST'not in b''.join(f.read_bytes()for f in v.out.rglob('*')if f.is_file());CASES.append({'case':'signedheader/stderr not retained','result':'EXPECTED_ACCEPTANCE'})
  subprocess.run=lambda *a,**k:types.SimpleNamespace(stdout=b'HTTP/2.0 403 Forbidden\r\n\r\n{"message":"forbidden"}',stderr=b'',returncode=1);reject('403 blocked',lambda:v.request('repos/'+REPO+'/test','mock403'))
  subprocess.run=lambda *a,**k:types.SimpleNamespace(stdout=b'HTTP/2.0 200 OK\r\n\r\nhttps://example.invalid/?sig=SECRET',stderr=b'',returncode=0);reject('secretbody blocked',lambda:v.request('repos/'+REPO+'/test','mocksecret',True));assert b'?sig=SECRET'not in b''.join(f.read_bytes()for f in v.out.rglob('*')if f.is_file())
 finally:subprocess.run=saved
# CLI fallback transport is explicitly mocked; real subprocess APIs stay denied.
for flavor,filename,wanted in [('study','exam-study-qa.yml',True),('representative','representative-quality-qa.yml',True),('wronghead','exam-study-qa.yml',False),('badexpected','exam-study-qa.yml',False),('empty','exam-study-qa.yml',False),('denied','exam-study-qa.yml',False),('timeout','exam-study-qa.yml',False),('secret','exam-study-qa.yml',False)]:
 with tempfile.TemporaryDirectory(prefix='SYNTHETIC-ONLY-postmerge-cli-fallback-',dir='/workspace/scratch')as tmp:
  v=N['Collector'](types.SimpleNamespace(candidate_sha=C,merge_sha=M,pages_run_id=900,output_new_dir=Path(tmp)/'new'));v.out.mkdir();v.created=True
  def DIRECT_BLOCKED(*args,**kwargs):raise ValueError('SOURCE_BLOCKED: explicit synthetic direct transport denial')
  v.request=DIRECT_BLOCKED
  def MOCK_VIEW(cmd,**kwargs):
   assert cmd==['gh','run','view','--repo',REPO,'--job','9061','--log']
   if flavor=='timeout':raise subprocess.TimeoutExpired(cmd,60,output=b'partial',stderr=b'SYNTHETIC-STDERR-DO-NOT-RETAIN')
   data=log(filename)
   if flavor=='wronghead':data=data.replace(('ref: '+M).encode(),('ref: '+'8'*40).encode())
   if flavor=='badexpected':data=data.replace(('EXPECTED_SHA: '+M).encode(),b'EXPECTED_SHA: wrong')
   if flavor=='empty':data=b''
   if flavor=='secret':data=b'https://example.invalid/?sig=DO-NOT-RETAIN'
   # Faithful gh run view job/step labels before original timestamp.
   data=b'\n'.join(b'production\tRun actions/checkout@v6\t'+line for line in data.splitlines())
   return types.SimpleNamespace(stdout=data,stderr=b'SYNTHETIC-STDERR-DO-NOT-RETAIN',returncode=1 if flavor=='denied'else 0)
  subprocess.run=MOCK_VIEW
  try:
   try:
    data,receipt=v.production_log(9061);assert receipt['HTTP_status']is None and receipt['HTTP_status_observable']is False;N['log_proof'](data,M,filename);accepted=True
   except ValueError:accepted=False
   assert accepted==wanted,(flavor,accepted,wanted)
   persisted=b''.join(f.read_bytes()for f in v.out.rglob('*')if f.is_file());assert b'DO-NOT-RETAIN'not in persisted
  finally:subprocess.run=DENY
 CASES.append({'case':'fully_stubbed_cli_fallback_'+flavor,'expected_acceptance':wanted,'actual_acceptance':accepted,'HTTP200_fabricated':False})
CLI=[]
for label,argv,wanted in [('help',['--help'],0),('missing',[],2),('badsha',['--candidate-sha','bad','--merge-sha',M,'--pages-run-id','9','--output-new-dir','/unused'],2)]:
 import contextlib,io
 stdout,stderr=io.StringIO(),io.StringIO()
 with contextlib.redirect_stdout(stdout),contextlib.redirect_stderr(stderr):
  try:N['parser']().parse_args(argv)
  except SystemExit as e:code=e.code
  else:raise AssertionError('CLI should exit in parse-only check')
 assert code==wanted;CLI.append({'case':label,'exit_code':code,'stdout_sha256':hashlib.sha256(stdout.getvalue().encode()).hexdigest(),'stderr_sha256':hashlib.sha256(stderr.getvalue().encode()).hexdigest(),'parse_only_in_process':True,'actual_API_calls':0})
result={'purpose':'OFFLINE_SYNTHETIC_POSTMERGE_COLLECTOR_TESTS_NOT_ACTUAL_COMPLETION_PROOF','observed_at_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'helper_path':str(P),'helper_sha256':hashlib.sha256(RAW).hexdigest(),'syntax_in_memory':True,'cases':CASES,'case_count':len(CASES),'CLI_cases':CLI,'all_results_expected':True,'temporary_synthetic_outputs_removed':True,'offline_rerun_real_subprocess_or_network_attempts':len(DENIED),'all_external_transports_deny_by_default':True,'ROOT_CI_deployment_mutations':0,'preparation_prior_unintentional_readonly_CLI_invocations':2,'preparation_total_actual_network_request_count':None,'boundary_deviation_receipt':'/workspace/scratch/final306-postmerge-collector-boundary-deviation.json','operational_proof_created':False,'prior_test_harness_draft_error':'An initial inline harness had a missing space in a Python conditional expression and did not execute; corrected external harness only, product helper was unchanged by that correction.','candidate_QA_or_release_credit':0}
assert not DENIED
out=Path('/workspace/scratch/final306-postmerge-collector-test-receipt.json');out.write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n');print(json.dumps({'path':str(out),'sha256':hashlib.sha256(out.read_bytes()).hexdigest(),'helper_sha256':result['helper_sha256'],'cases':len(CASES),'CLI_cases':len(CLI)}))
