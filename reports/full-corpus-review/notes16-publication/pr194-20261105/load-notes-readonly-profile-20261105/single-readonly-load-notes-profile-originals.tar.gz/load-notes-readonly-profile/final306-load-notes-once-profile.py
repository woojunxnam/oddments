"""One controller-authorized read-only call; profile artifacts outside checkout."""
import argparse,cProfile,datetime,hashlib,json,os,pstats,resource,sys,time,traceback
from pathlib import Path
import subprocess

p=argparse.ArgumentParser();p.add_argument('--root',type=Path,required=True);p.add_argument('--output',type=Path,required=True);a=p.parse_args()
root=a.root.resolve();out=a.output.resolve();out.mkdir(parents=True,exist_ok=False,mode=0o700)
sys.dont_write_bytecode=True
os.environ['PYTHONDONTWRITEBYTECODE']='1';os.environ['GIT_OPTIONAL_LOCKS']='0';os.environ['GIT_TERMINAL_PROMPT']='0'
def now():return datetime.datetime.now(datetime.timezone.utc).isoformat()
def sha(raw):return hashlib.sha256(raw).hexdigest()
def git(*args):return subprocess.check_output(['git','-C',str(root),*args])
head_before=git('rev-parse','HEAD').decode().strip();dirty_before=git('status','--porcelain=v1','--untracked-files=all');assert head_before=='156617b010ee54c3b6f599c88a2d8f6fa966011d'and not dirty_before
(out/'dirty-before.raw').write_bytes(dirty_before)
(out/'source-head-before.raw').write_text(head_before+'\n')
events=[];blocked=[]
def audit(event,args):
 if event=='open':
  path,mode,flags=args
  writing=(isinstance(mode,str)and any(x in mode for x in 'wax+'))or(isinstance(flags,int)and flags&(os.O_WRONLY|os.O_RDWR|os.O_CREAT|os.O_TRUNC|os.O_APPEND))
  if writing and isinstance(path,(str,bytes,os.PathLike)):
   target=Path(os.fsdecode(path)).resolve()
   if target==root or root in target.parents:
    blocked.append({'event':event,'path':str(target)});raise RuntimeError('Read-only profile forbids worktree write')
 elif event.startswith('socket.')and event not in {'socket.__new__'}:
  blocked.append({'event':event});raise RuntimeError('Profile forbids all network/DNS operations')
 elif event=='subprocess.Popen':
  executable,command,cwd,_env=args
  command=list(command)if not isinstance(command,str)else[command]
  name=Path(os.fsdecode(executable)).name
  if name=='git':
   words=[str(x)for x in command];allowed=any(x in words for x in ['show','rev-parse','ls-tree','cat-file','status','diff-tree','archive'])
  elif name.startswith('python'):
   allowed=any(str(x).endswith('/scripts/build_representative_rewrites.py')for x in command)and'--check'in command
  else:allowed=False
  record={'at_utc':now(),'event':event,'executable':os.fsdecode(executable),'command':[str(x)for x in command],'cwd':str(cwd)if cwd else None,'allowed_local_validation_only':allowed};events.append(record)
  if not allowed:blocked.append(record);raise RuntimeError('Profile forbids unexpected external/operational subprocess')
 elif event in {'os.system','os.exec','os.posix_spawn'}:
  blocked.append({'event':event});raise RuntimeError('Profile forbids alternate process transport')
sys.addaudithook(audit)
sys.path.insert(0,str(root/'scripts'));import notes_revision
profile=cProfile.Profile();wall_start=time.perf_counter();cpu_start=time.process_time();rself_before=resource.getrusage(resource.RUSAGE_SELF);rchild_before=resource.getrusage(resource.RUSAGE_CHILDREN);start=now();exit_code=0;result=None
try:
 profile.enable();result=notes_revision.load_notes(root);profile.disable()
except BaseException:
 profile.disable();exit_code=1;traceback.print_exc()
wall=time.perf_counter()-wall_start;cpu=time.process_time()-cpu_start;completed=now();rself_after=resource.getrusage(resource.RUSAGE_SELF);rchild_after=resource.getrusage(resource.RUSAGE_CHILDREN)
profile.dump_stats(str(out/'load-notes-once.cprofile'))
(out/'subprocess-audit.json').write_text(json.dumps(events,ensure_ascii=False,indent=2)+'\n')
(out/'blocked-operations.json').write_text(json.dumps(blocked,ensure_ascii=False,indent=2)+'\n')
head_after=git('rev-parse','HEAD').decode().strip();dirty_after=git('status','--porcelain=v1','--untracked-files=all');(out/'dirty-after.raw').write_bytes(dirty_after);(out/'source-head-after.raw').write_text(head_after+'\n')
assert head_after==head_before and dirty_after==dirty_before==b''
stats=pstats.Stats(profile);rows=[]
for(func,line,name),(pc,nc,tt,ct,callers)in stats.stats.items():rows.append({'file':func,'line':line,'function':name,'primitive_calls':pc,'calls':nc,'self_wall_seconds':tt,'cumulative_wall_seconds':ct})
for key,name in [('self_wall_seconds','top-self-wall.json'),('cumulative_wall_seconds','top-cumulative-wall.json')]:
 (out/name).write_text(json.dumps(sorted(rows,key=lambda x:x[key],reverse=True)[:100],ensure_ascii=False,indent=2)+'\n')
relevant=[x for x in rows if any(k in x['file']for k in ['notes_revision','notes_held_sixteenth','notes_published15_closure','notes_independent_metadata','notes_inactive_census_successor','notes_body_reassessment','notes_census_reassessment','realism_completion','procedural_secondary','phase11','legacy_independent','source3_recovered','remaining9_procedural','subprocess','json/decoder'])or any(k in x['function']for k in ['poll','waitpid','raw_decode','scan_once'])]
(out/'relevant-function-times.json').write_text(json.dumps(sorted(relevant,key=lambda x:x['cumulative_wall_seconds'],reverse=True),ensure_ascii=False,indent=2)+'\n')
with(out/'pstats-top.txt').open('w')as f:
 pstats.Stats(profile,stream=f).sort_stats('cumulative').print_stats(100);pstats.Stats(profile,stream=f).sort_stats('tottime').print_stats(100)
receipt={'purpose':'ACTUAL_SINGLE_READ_ONLY_LOAD_NOTES_PROFILE_NOT_QA_OR_OPTIMIZATION','started_at_utc':start,'completed_at_utc':completed,'exit_code':exit_code,'explicit_top_level_load_notes_invocations':1,'source_root':str(root),'source_head_before':head_before,'source_head_after':head_after,'dirty_before':'','dirty_after':'','wall_seconds':wall,'parent_process_CPU_seconds':cpu,'parent_resource_user_seconds':rself_after.ru_utime-rself_before.ru_utime,'parent_resource_system_seconds':rself_after.ru_stime-rself_before.ru_stime,'reaped_children_resource_user_seconds':rchild_after.ru_utime-rchild_before.ru_utime,'reaped_children_resource_system_seconds':rchild_after.ru_stime-rchild_before.ru_stime,'child_function_CPU_attribution':'UNKNOWN_NOT_PROFILED','cProfile_clock':'default wall elapsed: self/cumulative include waits, not per-function CPU samples','instrumentation':'Unchanged production code; cProfile and parent read-only/process/network audit only. Profiler/audit overhead not independently measured. No cache or optimization prototype.','subprocess_launches_during_or_after_profile':len(events),'blocked_operation_count':len(blocked),'result_summary':{'edition':result.get('edition'),'chapters':len(result['chapters']),'units':sum(len(c['units'])for c in result['chapters'])}if result else None,'new_QA_legal_or_release_credit':0,'current_fullQA_status':'NOT_ASSERTED_BY_THIS_PROFILE'}
(out/'profile-receipt.json').write_text(json.dumps(receipt,ensure_ascii=False,indent=2)+'\n');print(json.dumps(receipt,ensure_ascii=False));raise SystemExit(exit_code)
