공개 연습문항 전수 처분과 306개 노트 단위의 원자적 명제 census를 통합하고, 확인되지 않은 법적 주장을 보류합니다. 원본 문항 ID·본문·정답 이력·사용자 기록과 이전 부정 판정을 보존하며 기본 연습은 기존 202개를 유지합니다.

- 작성자 검토·독립 원문 실독: 각각 2,349/2,349. 독립 법규 정답 판정 2,312/2,349(98.42%, HOLD·AMBIGUOUS 포함). 미판정 37개는 기본 연습에서 제외합니다.
- 현실성 유효 PASS 880/2,349(37.46%). 새 법규 KEEP으로 이전 HOLD·FAIL을 해제하지 않습니다.
- 노트 census 306/306 COMPLETE, 7,086명제: KEEP 6,160·LEGAL_HOLD 36·SOURCE_BLOCKED 890. COMPLETE는 법규 PASS가 아닙니다. N1의 011 HOLD·daily 제외를 유지합니다.
- 9개 native 큐의 198개 작업이 모두 INTEGRATED이며 대기·활성 임대는 없습니다. authoritative planner의 실제 미검토 목록은 두 번 모두 비어 있었습니다.
- SATA 대체 3개는 독립 검토를 마친 archive-only 항목이며 원문 HOLD를 유지합니다. 전체 실질 교정률은 미확정이고 새 canonical RELEASED 승격은 0입니다.

실제 공개 PR #192의 source closure와 현재 5,131개 출처 바이트에 결박한 최종 manifest를 생성했습니다(SHA `4cf793e0293887a0e20dc5951cc694b596274954d872e20ced15601902f3fcf9`). 기존 승인·정책·release gate를 유지합니다. 출처 목록의 비결정적 출력 순서는 세 출력 사전만 정렬해 수정했고, 실제 실패 로그와 8개 출력의 JSON 값 대조를 보존했습니다. CI 시간 한도 네 곳만 늘렸으며 모든 검사 명령과 조건을 유지합니다. 현재 source로 대표 audit-ledger·유사도·quality 화면을 정규 재생성했고 canonical 생성물에는 drift가 없었습니다.

이전 후보 `9a4e3764`의 전체 pytest는 실제 **1,788 PASS·1 FAIL**이었습니다. 유일한 실패는 archive warning 테스트의 임시 디렉터리에 Git HEAD가 없어서 발생했습니다. 새 후보에서는 테스트에 Git 초기화와 빈 최초 commit만 추가했습니다. 기존 모듈 AST에서 이 준비 코드와 import를 제외한 부분, assertion·예외 검증 14개, production 보호 코드와 manifest 입력 5,131개는 동일함을 독립 검토했습니다. 실패한 전체 QA 로그는 [별도 증거 체크포인트](https://github.com/woojunxnam/oddments/blob/2f12448f79bed2bdb874166cca794dc67cceca48/reports/full-corpus-review/notes16-publication/pr194-20261105/actual-9a4e-pr-qa-failure/checkpoint.json)에 보존했습니다.

후보: `CANDIDATE_SHA_PENDING`. 수정된 실패 node의 실제 단독 검사는 1 PASS입니다. 관련 모듈 결과와 새 후보의 전체 pytest·결정적 artifact·보호 검사·GitHub CI는 실제 완료 결과를 기록합니다. 이전 후보나 PR #193의 QA를 이 후보의 통과로 사용하지 않습니다. 모든 필수 gate를 통과하기 전에는 draft를 유지합니다.

병합 뒤 새 Pages 실행과 canonical 공개 파일 40개, 5종 실제 공개 브라우저 검사, main workflow 및 production 검증을 별도 실제 결과로 기록합니다. 새 후보의 실제 공개 URL 검증과 배포는 아직 미실행입니다.

출처·원장·native 절차 증거: `reports/full-corpus-review/`. 최종 source 결박: `reports/full-corpus-review/resume-20261105/final306-manifest-binding/`. 이전 후보의 로컬 보호 검사 증거는 [독립 증거 브랜치](https://github.com/woojunxnam/oddments/blob/84f653d1d98a72d94acb24a50a76a46154f5aeee/reports/full-corpus-review/notes16-publication/pr194-20261105/premerge-local-checkpoint/checkpoint.json)에 보존하며 현재 후보 QA와 구별합니다.
