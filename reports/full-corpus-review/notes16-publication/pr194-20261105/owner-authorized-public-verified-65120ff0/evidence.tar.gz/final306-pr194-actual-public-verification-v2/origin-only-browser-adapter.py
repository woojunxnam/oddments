from pathlib import Path
import ast,json,sys
ROOT=Path('/workspace/mpje-pr194-public-merge')
OUT=Path('/workspace/scratch/final306-pr194-actual-public-verification-v2')
sys.path.insert(0,'/workspace/scratch')
from final306_public_verifier import adapt_browser_source
name=sys.argv[1]
assert name in {'verify_notes_browser.py','verify_refresh_browser.py'}
assert '--inline-preview' not in sys.argv
p=ROOT/'scripts'/name
adapted,proof=adapt_browser_source(name,p.read_text())
(OUT/(name+'.origin-adapter.json')).write_text(json.dumps(proof,indent=2)+'\n')
sys.path.insert(0,str(ROOT/'scripts'))
sys.argv=[str(p),*sys.argv[2:]]
exec(compile(adapted,str(p),'exec'),{'__name__':'__main__','__file__':str(p)})
