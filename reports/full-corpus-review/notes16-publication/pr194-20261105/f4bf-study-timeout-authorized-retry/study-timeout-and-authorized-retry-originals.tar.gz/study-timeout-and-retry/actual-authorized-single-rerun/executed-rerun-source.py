from pathlib import Path
import datetime,hashlib,json,os,re,subprocess
HEAD='f4bf5dd17c414d1117c3decf0b5cab27023b16cc';RUN=41992445169;BRANCH='mission/mpje-after193-wave12';REPO='woojunxnam/oddments';now=lambda:datetime.datetime.now(datetime.timezone.utc).isoformat();H=lambda b:hashlib.sha256(b).hexdigest()
O=Path('/workspace/scratch/final306-candidate-ci-observations')/('rerun-study-f4bf-once-'+datetime.datetime.now(datetime.timezone.utc).strftime('%Y%m%dT%H%M%SZ'));O.mkdir();ENV={k:v for k,v in os.environ.items()if k not in {'GH_DEBUG','DEBUG'}};counter=0
(O/'executed-rerun-source.py').write_bytes(Path(__file__).read_bytes())
def save(n,x):p=O/n;p.write_text(json.dumps(x,ensure_ascii=False,indent=2)+'\n');return p

def api(method,endpoint,label):
 global counter
 counter+=1;label=f'{counter:02d}-'+label;cmd=['gh','api','--hostname','github.com','--include','--method',method,endpoint];start=now()
 try:p=subprocess.run(cmd,capture_output=True,env=ENV,timeout=30);raw,err,code=p.stdout,p.stderr,p.returncode
 except subprocess.TimeoutExpired as e:raw,err,code=e.stdout or b'',e.stderr or b'',None
 codes=re.findall(rb'^HTTP/\S+\s+(\d+)',raw,re.M);status=int(codes[-1])if codes else None;parts=re.split(b'\r?\n\r?\n',raw,maxsplit=1);body=parts[1]if len(parts)==2 else b'';(O/(label+'.http.raw')).write_bytes(raw);(O/(label+'.body.raw')).write_bytes(body);rec={'started_at_utc':start,'completed_at_utc':now(),'command':cmd,'actual_exit_code':code,'actual_HTTP_status':status,'raw_sha256':H(raw),'body_sha256':H(body),'stderr_sha256':H(err),'stderr_original_bytes':len(err),'stderr_original_content_retained':False};save(label+'.receipt.json',rec)
 if method=='GET'and(code!=0 or status!=200):raise RuntimeError('Official fresh GET failed; no mutation is authorized without complete prechecks')
 try:data=json.loads(body or b'{}')
 except json.JSONDecodeError:data=None
 return data,rec

def run_binding(r):
 assert r['id']==RUN and r['head_sha']==HEAD and r['head_branch']==BRANCH and r['event']=='pull_request'and r['path']=='.github/workflows/exam-study-qa.yml'

pr,prproof=api('GET',f'repos/{REPO}/pulls/194','fresh-current-pr194');assert pr['head']['sha']==HEAD and pr['head']['ref']==BRANCH and pr['head']['repo']['full_name']==REPO and pr['base']['ref']=='main'and pr['state']=='open'
run,runproof=api('GET',f'repos/{REPO}/actions/runs/{RUN}','fresh-current-study-run');run_binding(run);assert run['run_attempt']==1 and run['status']=='completed'and run['conclusion']=='cancelled'
annotations,annproof=api('GET',f'repos/{REPO}/check-runs/127127613297/annotations?per_page=100','fresh-timeout-annotations');assert any(a.get('message')=='The job has exceeded the maximum execution time of 1h0m0s'for a in annotations)
oldlog=Path('/workspace/scratch/final306-candidate-ci-observations/monitor-f4bf-20261105T081123Z/run-41992445169-attempt-1-job-127127613297.log');raw=oldlog.read_bytes();assert H(raw)=='8658a59204c22c13b662e8d2dd05e0e97701da6d1926def76f9988ebaf7dc792'and b'103 passed in 2681.92s (0:44:41)'in raw;(O/'original-attempt1-study.log').write_bytes(raw)
auth={'purpose':'EXPLICIT_ONE_RETRY_SAME_EXACT_CANDIDATE_STUDY_ONLY_AFTER_CONFIRMED60MIN_TIMEOUT','observed_at_utc':now(),'actual_candidate':HEAD,'run_id':RUN,'before_attempt':1,'current_PRhead_verified':True,'actual_timeout_annotation_verified':True,'partial_103_pass_original_log_sha256':H(raw),'old_partial_is_not_workflow_success':True,'allowed_first_endpoint':'rerun-failed-jobs','same_run_rerun_fallback_only_after_explicit_endpoint_nonacceptance':True,'accepted_POST_must_not_be_duplicated':True,'future_attempt3_authorized':False,'ROOT_other_workflows_cancel_or_source_changes':0};save('authorization-and-prechecks-before-POST.json',auth)
_,post=api('POST',f'repos/{REPO}/actions/runs/{RUN}/rerun-failed-jobs','authorized-rerun-failed-jobs');posts=[post];accepted=post['actual_exit_code']==0 and post['actual_HTTP_status']in{201,202}
if not accepted and post['actual_HTTP_status']in{400,404,405,409,422,501}:
 # Never duplicate a possibly accepted request: fresh actual attempt must still be1.
 current,_=api('GET',f'repos/{REPO}/actions/runs/{RUN}','confirm-not-accepted-before-fallback');run_binding(current)
 if current['run_attempt']==1 and current['status']=='completed':
  _,fallback=api('POST',f'repos/{REPO}/actions/runs/{RUN}/rerun','authorized-same-run-full-rerun-fallback');posts.append(fallback);accepted=fallback['actual_exit_code']==0 and fallback['actual_HTTP_status']in{201,202}
 elif current['run_attempt']>1:accepted=True
summary={'purpose':auth['purpose'],'completed_at_utc':now(),'run_id':RUN,'candidate_sha':HEAD,'attempt1_result':'CANCELLED_CONFIRMED60MIN_TIMEOUT_103PARTIAL_PASS_NOT_WORKFLOW_PASS','POSTs':posts,'actual_rerun_request_accepted':accepted,'original_attempt1_bytes_preserved':True,'no_more_POSTs_authorized':True,'new_attempt_workflow_result':'PENDING_ACTUAL_NEW_GITHUB_OBSERVATION','ROOT_source_native_other_CI_mutations':0,'candidate_full_QA_or_release_credit':0}
p=save('request-summary.json',summary);print(json.dumps({'directory':str(O),'request_summary':str(p),'sha256':H(p.read_bytes()),'accepted':accepted,'POST_actual_HTTP_statuses':[x['actual_HTTP_status']for x in posts],'POSTs':len(posts)},ensure_ascii=False),flush=True)
if not accepted:raise SystemExit(1)
