공개 연습문항 전수 처분과 306개 노트 단위의 원자적 명제 census를 통합합니다. 공식 자료를 확인하지 못하거나 사실관계가 부족한 항목은 보류하며, 원본 문항 ID·본문·정답 이력·사용자 시도·북마크와 이전 부정 판정을 보존합니다. 기본 연습은 기존 202개를 유지합니다.

**사용자 요청으로 새 작업을 중단하고 완료분을 동결했습니다. 후보 `bbb5daa9c88612c080661bd93f080afd3663495d`는 push 완료·draft·배포 차단 상태입니다.** 현재 후보의 원격 CI는 계속 실행하며, 이전 HEAD의 중복 전체 pytest 두 실행은 부분 로그를 보존한 뒤 취소했습니다. 필수 검사 미완료 상태에서 병합·배포하지 않습니다.

- 작성자 검토 및 독립 원문 실독·처분: 각각 2,349/2,349. 독립 법규 정답 판정 2,312/2,349(98.42%, HOLD·AMBIGUOUS 포함), 미판정 37개는 기본 연습에서 제외합니다.
- 현실성 유효 PASS 880/2,349(37.46%). 새 법규 KEEP으로 이전 HOLD·FAIL을 해제하지 않습니다.
- 노트 census 306/306 COMPLETE, 7,086명제: KEEP 6,160·LEGAL_HOLD 36·SOURCE_BLOCKED 890. COMPLETE는 법규 PASS가 아닙니다. 기존 011 HOLD·N1 daily 제외를 유지합니다.
- 9개 native 큐의 198개 작업 모두 INTEGRATED. 실제 미검토 planner는 두 번 모두 빈 목록이었으며 대기·활성 임대는 없습니다.
- 알려진 SATA 대체 3개는 독립 검토된 archive-only 항목이며 원문 HOLD를 유지합니다. 전체 실질 교정률은 미확정, 새 canonical RELEASED 승격은 0입니다.

실제 공개 PR #192의 source closure와 검토·생성 입력 파일 5,131개 바이트에 결박한 최종 manifest를 생성했습니다(SHA `4cf793e0293887a0e20dc5951cc694b596274954d872e20ced15601902f3fcf9`). 기존 승인·정책·보호·release gate를 유지합니다. 비결정적 출처 목록 순서는 출력 사전 세 곳만 정렬해 수정했고, 대표 audit-ledger·유사도·quality 화면을 현재 source로 재생성했습니다. canonical 정규 재생성에는 drift가 없었습니다.

실제 CI에서 발견한 archive warning fixture의 Git HEAD 부재는 테스트 준비 코드만 추가해 수정했습니다(기존 모듈·assertion/예외 검증 14개 유지, 관련 모듈 12 PASS). 이후 study 두 실행의 공식 60분 시간 초과에는 study 한도 120분을 적용했고, 해당 HEAD에서 workflow 전체가 각각 68분·70분에 통과했습니다. 대표 이력 검사의 공식 180분 시간 초과에는 revision 한도만 300분으로 수정했습니다. 모두 명령·조건·production 검사·validator를 보존한 시간 예산 변경이며, 이전 HEAD의 PASS와 부분 pytest 결과를 현재 후보의 QA PASS로 이월하지 않습니다. 이전 PR #193의 1,498개 테스트·배포 증거도 이번 후보 QA로 재사용하지 않습니다.

현재 bbb5daa9의 clean checkout에서 공개 예정 파일 40개를 실제 생성했습니다(199.77초, exit 0; manifest SHA `92473f441ec834b13a8f6552dcaaf4e017a1cf100db4c8977a37114afd056d23`). 이는 실제 공개 URL·브라우저·배포 검증이 아닙니다. 현재 후보의 전체 pytest·대표 이력 검사·canonical artifact·GitHub CI 완료 결과를 확인해야 합니다. 자동 병합·배포는 예약하지 않았습니다.

[누적 증거 브랜치](https://github.com/woojunxnam/oddments/tree/evidence/pr194-final306-20261105/reports/full-corpus-review/notes16-publication/pr194-20261105)에는 실제 실패·시간 초과·취소·부분 결과, source 보존과 독립 검토·원 SHA를 따로 보존합니다. 재개 시 현재 HEAD와 실제 GitHub 결과를 확인하고 모든 release gate가 통과한 경우에만 병합합니다. 이어 새 Pages 실행, canonical 공개 파일 40개, 5종 실제 공개 브라우저 검사, main 9개 및 production 2개, authoritative planner의 미검토 4×40 자동 선택을 실제 결과로 기록합니다. 현재 공개 배포는 검증 완료된 PR #193을 유지합니다.
