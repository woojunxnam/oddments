from pathlib import Path
import datetime,hashlib,json,os,re,subprocess
HEAD='156617b010ee54c3b6f599c88a2d8f6fa966011d';NEW='bbb5daa9c88612c080661bd93f080afd3663495d';BRANCH='mission/mpje-after193-wave12';REPO='woojunxnam/oddments';TARGETS={42009679584:('pull_request','.github/workflows/qa.yml'),42009664686:('push','.github/workflows/qa.yml')};now=lambda:datetime.datetime.now(datetime.timezone.utc).isoformat();H=lambda b:hashlib.sha256(b).hexdigest();O=Path('/workspace/scratch/final306-candidate-ci-observations')/('cancel-pause-obsolete1566-QA2-'+datetime.datetime.now(datetime.timezone.utc).strftime('%Y%m%dT%H%M%SZ'));O.mkdir();ENV={k:v for k,v in os.environ.items()if k not in{'GH_DEBUG','DEBUG'}};serial=0
(O/'executed-cancellation-source.py').write_bytes(Path(__file__).read_bytes())
def save(n,x):p=O/n;p.write_text(json.dumps(x,ensure_ascii=False,indent=2)+'\n');return p

def api(method,endpoint,label):
 global serial
 serial+=1;label=f'{serial:02d}-'+label;cmd=['gh','api','--hostname','github.com','--include','--method',method,endpoint];start=now();r=subprocess.run(cmd,capture_output=True,env=ENV,timeout=30);raw=r.stdout;parts=re.split(b'\r?\n\r?\n',raw,maxsplit=1);body=parts[1]if len(parts)==2 else b'';codes=re.findall(rb'^HTTP/\S+\s+(\d+)',raw,re.M);status=int(codes[-1])if codes else None;(O/(label+'.http.raw')).write_bytes(raw);(O/(label+'.body.raw')).write_bytes(body);rec={'started_at_utc':start,'completed_at_utc':now(),'command':cmd,'actual_exit_code':r.returncode,'HTTP_status':status,'raw_sha256':H(raw),'body_sha256':H(body),'stderr_sha256':H(r.stderr),'stderr_bytes':len(r.stderr),'stderr_content_retained':False};save(label+'.receipt.json',rec)
 if r.returncode:raise RuntimeError('Official API unsuccessful; stop without inferred acceptance')
 return json.loads(body or b'{}'),rec

# Preserve all already-available actual partial logs/status BEFORE any mutation.
old=Path('/workspace/scratch/final306-candidate-ci-observations/monitor-1566-20261105T102007Z');preserved={}
for f in [old/'latest-summary.json']:
 b=f.read_bytes();(O/('pre-action-'+f.name)).write_bytes(b);preserved[str(f)]={'sha256':H(b),'bytes':len(b)}
pre={}
for rid,(event,path)in TARGETS.items():
 d,rec=api('GET',f'repos/{REPO}/actions/runs/{rid}','fresh-pre-action-'+str(rid));assert rec['HTTP_status']==200 and d['id']==rid and d['head_sha']==HEAD and d['head_branch']==BRANCH and d['event']==event and d['path']==path and d['repository']['full_name']==REPO;pre[rid]={'data':d,'receipt':rec}
 jobs,jobsrec=api('GET',f'repos/{REPO}/actions/runs/{rid}/jobs?per_page=100','fresh-pre-action-jobs-'+str(rid));assert jobsrec['HTTP_status']==200
 # Preserve actual existing job step payload/receipt, not invented in-progress log bytes.
 f=max(old.glob(f'*-jobs-{rid}-cycle-*.body.raw'),key=lambda x:int(x.name.split('-')[0]));stem=f.name[:-len('.body.raw')]
 for suffix in ['.body.raw','.http.raw','.receipt.json']:
  p=old/(stem+suffix);b=p.read_bytes();(O/('pre-action-'+p.name)).write_bytes(b);preserved[str(p)]={'sha256':H(b),'bytes':len(b)}
allow={'purpose':'EXPLICIT_USER_PAUSE_OBSOLETE1566_QA2_ONLY_KEEP_NEW_BBB10_REMOTE_RUNNING','observed_at_utc':now(),'obsolete_candidate':HEAD,'new_candidate_NEVER_CANCEL':NEW,'branch':BRANCH,'root_explicit_run_ids':list(TARGETS),'pending_allowlist':[rid for rid,v in pre.items()if v['data']['status']in{'queued','in_progress'}],'actual_pre_action_statuses':{rid:{k:v['data'].get(k)for k in['id','head_sha','head_branch','event','path','run_attempt','status','conclusion']}for rid,v in pre.items()},'pre_action_source_bytes':preserved,'inprogress_partial_log_limit':'Only actual already-available logs/retained job step payloads preserved here. Still-running job log not fabricated; actual terminal cancellation log collected by existing observer afterward.','already_terminal7success_and_representative_timeout_untouched':True,'ROOT_newcandidate_main_evidence_otherheads_mutations':0,'PASS_credit':0};save('allowlist-before-any-POST.json',allow)
posts=[]
for rid in allow['pending_allowlist']:
 _,rec=api('POST',f'repos/{REPO}/actions/runs/{rid}/cancel','authorized-cancel-'+str(rid));assert rec['HTTP_status']==202;posts.append({'run_id':rid,'receipt':rec})
summary={'purpose':allow['purpose'],'completed_at_utc':now(),'obsolete_candidate':HEAD,'new_candidate_never_mutated':NEW,'authorized_cancel_requests':posts,'cancel_request_count':len(posts),'terminal_existing_runs_changed':0,'ROOT_source_native_main_evidence_otherhead_mutations':0,'pending_final_status_observation':True,'success_credit':0};p=save('cancellation-request-summary.json',summary);print(json.dumps({'directory':str(O),'summary':str(p),'sha256':H(p.read_bytes()),'cancel_request_count':len(posts),'HTTP_statuses':[x['receipt']['HTTP_status']for x in posts]},ensure_ascii=False))
