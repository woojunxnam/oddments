from pathlib import Path
import ast,copy,datetime,hashlib,json,re,subprocess,socket,urllib.request,http.client,os
src=Path('/workspace/scratch/final306_collect_postmerge.py');raw=src.read_bytes();assert hashlib.sha256(raw).hexdigest()=='a755658a0bcb4e5b24dfad870e2a34b7efb36d20c060e2528d5dae3e03084aa8';tree=ast.parse(raw);allowed={'sha','require','moment','declared_step_name','verify_steps','matching_run','latest_run','run_identity','log_proof'}
functions=[n for n in tree.body if isinstance(n,ast.FunctionDef)and n.name in allowed];assert{n.name for n in functions}==allowed
calls=[]
def deny(*a,**k):calls.append('BLOCKED');raise AssertionError('Peer pure harness forbids all subprocess/network operations')
for n in ['run','Popen','check_output','check_call','call']:setattr(subprocess,n,deny)
socket.socket=deny;socket.create_connection=deny
for name in ['getaddrinfo','gethostbyname','gethostbyname_ex','gethostbyaddr']:setattr(socket,name,deny)
urllib.request.urlopen=deny;urllib.request.OpenerDirector.open=deny
http.client.HTTPConnection.connect=deny;http.client.HTTPSConnection.connect=deny
os.system=deny;os.popen=deny
ns={'hashlib':hashlib,'re':re,'datetime':datetime.datetime,'timezone':datetime.timezone,'ORIGIN':'https://woojunxnam.github.io/oddments/'}
exec(compile(ast.Module(body=functions,type_ignores=[]),str(src)+'::PURE_FUNCTIONS_ONLY','exec'),ns)
results=[]
def check(name,fn,negative=False):
 try:fn()
 except (ValueError,KeyError,UnicodeError)as e:
  if not negative:raise
  results.append({'case':name,'result':'PASS_REJECTED','error':str(e)})
 else:
  assert not negative,name+' unexpectedly accepted';results.append({'case':name,'result':'PASS_ACCEPTED'})
merge='a'*40;other='b'*40
base=[f'ref: {merge}','[command]/usr/bin/git log -1 --format=%H',merge,f'EXPECTED_SHA: {merge}','Production exam-study assets match the merged source byte-for-byte.','Production full-note content, manifest, HTML and Markdown exports match the merged source byte-for-byte.']
formats={'plain':lambda x:x,'timestamp':lambda x:'2026-11-05T12:00:00.0000000Z '+x,'gh-tab':lambda x:'production\tCheckout\t2026-11-05T12:00:00.0000000Z '+x,'gh-tab-no-timestamp':lambda x:'production\tCheckout\t'+x}
for name,fmt in formats.items():
 def b(lines):return('\n'.join(fmt(x)for x in lines)+'\n').encode()
 check('study-valid-'+name,lambda:ns['log_proof'](b(base),merge,'exam-study-qa.yml'))
 for idx,description in [(0,'checkout-input'),(2,'actual-HEAD'),(3,'EXPECTED_SHA')]:
  lines=base.copy();lines[idx]=lines[idx].replace(merge,other);check('study-reject-'+description+'-'+name,lambda lines=lines:ns['log_proof'](b(lines),merge,'exam-study-qa.yml'),True)
 for idx in [0,1,2,3,4,5]:
  lines=base[:idx]+base[idx+1:];check('study-reject-missing-'+str(idx)+'-'+name,lambda lines=lines:ns['log_proof'](b(lines),merge,'exam-study-qa.yml'),True)
 rep=base[:3]+['python scripts/verify_representative_rewrites.py --base-url '+ns['ORIGIN'],'every new case (77) passes wrong/correct grading, shuffled-letter mapping, exact citation links and 320px layout','backup/import keeps all old and revised attempts under their own IDs','no uncaught JavaScript errors']
 check('representative-valid-'+name,lambda:ns['log_proof'](b(rep),merge,'representative-quality-qa.yml'))
 for idx in [3,4,5,6]:
  lines=rep[:idx]+rep[idx+1:];check('representative-missing-completion-'+str(idx)+'-'+name,lambda lines=lines:ns['log_proof'](b(lines),merge,'representative-quality-qa.yml'),True)
workflow={'steps':[{'name':'Checkout','uses':'actions/checkout@v6'},{'uses':'actions/setup-python@v5'},{'name':'Verify','run':'actual-command'}]}
actual=[{'name':x,'status':'completed','conclusion':'success'}for x in ['Set up job','Checkout','Run actions/setup-python@v5','Verify','Post Checkout','Complete job']]
check('all-source-steps-success',lambda:ns['verify_steps'](actual,workflow))
for field,val in [('status','in_progress'),('conclusion','failure'),('conclusion','skipped'),('conclusion','neutral'),('conclusion',None)]:
 a=copy.deepcopy(actual);a[3][field]=val;check('required-step-reject-'+field+'-'+str(val),lambda a=a:ns['verify_steps'](a,workflow),True)
for label,a in [('missing',actual[:3]+actual[4:]),('duplicate',actual+[actual[3]]),('unknown',actual+[{'name':'Unknown','status':'completed','conclusion':'success'}])]:check('step-shape-reject-'+label,lambda a=a:ns['verify_steps'](a,workflow),True)
run={'path':'.github/workflows/qa.yml','event':'push','head_sha':merge,'head_branch':'main'}
check('exact-main-run-match',lambda:ns['require'](ns['matching_run'](run,'qa.yml','push',merge),'exact should match'))
for key,val in [('path','.github/workflows/wrong.yml'),('event','pull_request'),('head_sha',other),('head_branch','mission/other')]:
 a=dict(run);a[key]=val;check('reject-wrong-run-'+key,lambda a=a:ns['require'](not ns['matching_run'](a,'qa.yml','push',merge),'wrong should reject'))
for ts in ['2026-11-05T00:00:00Z','2026-11-05T00:00:00+00:00']:check('UTC-accept-'+ts,lambda ts=ts:ns['moment'](ts))
for ts in ['2026-11-05T00:00:00','2026-11-05T00:00:00+09:00',None]:check('UTC-reject-'+str(ts),lambda ts=ts:ns['moment'](ts),True)
assert not calls
receipt={'purpose':'INDEPENDENT_POSTMERGE_COLLECTOR_PURE_FUNCTION_AST_REVIEW_NOT_OPERATIONAL_RUN','observed_at_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'helper_path':str(src),'helper_sha256':hashlib.sha256(raw).hexdigest(),'selected_function_names':sorted(allowed),'entire_Collector_or_main_or_request_executed':False,'network_subprocess_policy':'deny-by-default monkeypatches installed before compiling/executing selected function AST; no entire-module execution/import','blocked_operation_attempts':len(calls),'actual_network_or_collector_API_calls':0,'actual_CI_mutations_ROOT_browser_publisher_deployment':0,'case_count':len(results),'results':results,'new_QA_legal_canonical_release_credit':0}
p=Path('/workspace/scratch/final306-postmerge-collector-peer-pure-receipt-final.json');p.write_text(json.dumps(receipt,ensure_ascii=False,indent=2)+'\n');print(json.dumps({'receipt':str(p),'sha256':hashlib.sha256(p.read_bytes()).hexdigest(),'cases':len(results),'helper_sha256':receipt['helper_sha256'],'actual_network_calls':0,'entire_module_executed':False}))
