from pathlib import Path
import datetime,hashlib,json,os,re,subprocess,urllib.parse
REPO='woojunxnam/oddments';BRANCH='evidence/pr194-final306-20261105';R=Path('/workspace/mpje-pr194-evidence');PREFIXES=['84f653d','2f12448','c798e9b','7b0a503','8401a67','15b0923','7e69035'];PATHS={'.github/workflows/qa.yml','.github/workflows/representative-quality-qa.yml'};now=lambda:datetime.datetime.now(datetime.timezone.utc).isoformat();H=lambda b:hashlib.sha256(b).hexdigest();O=Path('/workspace/scratch/final306-candidate-ci-observations')/('cancel-owned-evidence-checkpoints-'+datetime.datetime.now(datetime.timezone.utc).strftime('%Y%m%dT%H%M%SZ'));O.mkdir();ENV={k:v for k,v in os.environ.items()if k not in{'GH_DEBUG','DEBUG'}};serial=0
(O/'executed-cancellation-source.py').write_bytes(Path(__file__).read_bytes())
def save(n,x):p=O/n;p.write_text(json.dumps(x,ensure_ascii=False,indent=2)+'\n');return p

def api(method,endpoint,label):
 global serial
 serial+=1;label=f'{serial:03d}-'+label;cmd=['gh','api','--hostname','github.com','--include','--method',method,endpoint];start=now();r=subprocess.run(cmd,capture_output=True,env=ENV,timeout=30);raw=r.stdout;parts=re.split(b'\r?\n\r?\n',raw,maxsplit=1);body=parts[1]if len(parts)==2 else b'';codes=re.findall(rb'^HTTP/\S+\s+(\d+)',raw,re.M);status=int(codes[-1])if codes else None;(O/(label+'.http.raw')).write_bytes(raw);(O/(label+'.body.raw')).write_bytes(body);rec={'started_at_utc':start,'completed_at_utc':now(),'command':cmd,'actual_exit_code':r.returncode,'HTTP_status':status,'raw_sha256':H(raw),'body_sha256':H(body),'stderr_sha256':H(r.stderr),'stderr_bytes':len(r.stderr),'stderr_content_retained':False};save(label+'.receipt.json',rec)
 if r.returncode:raise RuntimeError('Actual official API error; stop without fabricated status')
 return json.loads(body or b'{}'),rec

heads={p:subprocess.check_output(['git','-C',str(R),'rev-parse','--verify',p+'^{commit}']).decode().strip()for p in PREFIXES};tip=subprocess.check_output(['git','-C',str(R),'rev-parse','HEAD']).decode().strip();assert tip==heads['7e69035']
for h in heads.values():assert subprocess.run(['git','-C',str(R),'merge-base','--is-ancestor',h,tip],capture_output=True).returncode==0
save('actual-fullSHA-allowlist-before-API.json',{'purpose':'EXPLICIT_OWN_EVIDENCE_ONLY_AUTOMATIC_PUSH_QA_REPRESENTATIVE_CHECKPOINT_CLEANUP','observed_at_utc':now(),'repository':REPO,'branch':BRANCH,'actual_evidence_tip':tip,'actual_checkpoint_full_SHAs':heads,'allowed_workflow_paths':sorted(PATHS),'required_event':'push','required_run_attempt':1,'manual_workflow_dispatch_or_reruns_excluded':True,'candidate1566_main_otherbranches_never_targeted':True,'PASS_credit':0})
runs=[]
for page in range(1,30):
 endpoint=f'repos/{REPO}/actions/runs?'+urllib.parse.urlencode({'branch':BRANCH,'event':'push','per_page':100,'page':page});d,rec=api('GET',endpoint,'evidence-branch-list-'+str(page));assert rec['HTTP_status']==200;batch=d['workflow_runs'];runs.extend(batch)
 if len(batch)<100:break
else:raise RuntimeError('Unproven complete pagination: no mutation')
def in_scope(d):return(d.get('repository',{}).get('full_name')==REPO and d.get('head_branch')==BRANCH and d.get('head_sha')in heads.values()and d.get('event')=='push'and d.get('path')in PATHS and d.get('run_attempt')==1)
candidates=[d for d in runs if in_scope(d)and d['status']in{'queued','in_progress'}];pre=[]
for run in candidates:
 d,rec=api('GET',f'repos/{REPO}/actions/runs/{run["id"]}','fresh-pre-run-'+str(run['id']));assert rec['HTTP_status']==200 and in_scope(d)
 jobs,jrec=api('GET',f'repos/{REPO}/actions/runs/{run["id"]}/jobs?per_page=100','pre-action-jobs-'+str(run['id']));assert jrec['HTTP_status']==200 and jobs.get('total_count',len(jobs['jobs']))<=len(jobs['jobs'])
 pre.append({'run':{k:d.get(k)for k in ['id','head_sha','head_branch','event','path','run_attempt','status','conclusion']},'run_API_receipt':rec,'job_step_payload_saved_with_receipt':jrec})
allow={'created_at_utc':now(),'strict_scope_fullSHAs':heads,'actual_pre_action_runs':pre,'allowed_pending_run_ids':[r['run']['id']for r in pre if r['run']['status']in{'queued','in_progress'}],'terminal_runs_from_list_untouched':sum(in_scope(r)and r['status']=='completed'for r in runs),'manual_otherhead_otherbranch_nonmatching_excluded':True,'PASS_credit':0};save('allowlist-before-any-POST.json',allow)
posts=[]
for rid in allow['allowed_pending_run_ids']:
 # Fresh recheck immediately before each mutation; terminal changes are never touched.
 d,rec=api('GET',f'repos/{REPO}/actions/runs/{rid}','immediate-pre-POST-'+str(rid));assert rec['HTTP_status']==200 and in_scope(d)
 if d['status']not in{'queued','in_progress'}:continue
 _,post=api('POST',f'repos/{REPO}/actions/runs/{rid}/cancel','authorized-owned-evidence-cancel-'+str(rid));assert post['HTTP_status']==202;posts.append({'run_id':rid,'response':post})
summary={'purpose':'OWNED_EVIDENCE_ONLY_CHECKPOINT_CANCEL_REQUESTS_NOT_VERIFICATION_SUCCESS','completed_at_utc':now(),'actual_allowed_fullSHAs':heads,'evidence_branch':BRANCH,'request_count':len(posts),'requests':posts,'terminal_existing_runs_changed':0,'candidate1566_f4bf_main_otherbranches_changed':0,'ROOT_files_workflows_validators_changed':0,'PASS_credit':0,'final_status_observation_pending':True};p=save('cancellation-request-summary.json',summary);print(json.dumps({'directory':str(O),'summary':str(p),'sha256':H(p.read_bytes()),'pending_seen':len(candidates),'cancel_request_count':len(posts),'HTTP_statuses':[x['response']['HTTP_status']for x in posts]},ensure_ascii=False),flush=True)
