Medicaid outpatient DUR 체계에서는 조제·교부 전 약물치료 검토, 환자 profile, 상담 기준이 연결된다. Prospective review는 duplication, contraindication, interaction, dose·duration, allergy, abuse/misuse 등을 다룬다. Offer와 실제 counseling의 수행·거절·기록 및 우편 조제 상황의 기준은 주의 요구와 함께 적용한다. 

연방 규정이 Medicaid beneficiaries를 다룬다는 사실을 ‘현금 환자나 일반 보험 환자는 Massachusetts counseling 대상이 아니다’로 바꾸지 않는다. Massachusetts는 247 CMR 9.17–9.18의 독립적인 DUR·counseling 의무를 두며, [관련 장](#chapter/pharmacy-mor)·[상담·DUR 장](#chapter/counseling-dur)가 그 실제 적용을 설명한다. 

Offer to counsel, counseling itself, written leaflet는 동일한 행동이 아니다. Patient refusal, 단순히 환자를 만나지 못한 경우, 직원이 먼저 거절한 것으로 처리한 경우도 같지 않다. Printed information나 Medication Guide를 넣었다는 사실만으로 모든 상담 의무가 자동 완료되지 않는다.