False Claims Act: federal-program 청구에서 사실을 알면서 허위·사기 청구를 하거나 deliberate ignorance·reckless disregard로 행동하는 문제이다. 특별한 사기 의도가 없다는 주장만으로 civil FCA 책임이 항상 없어지는 것은 아니다. 실제로 교부하지 않은 약을 교부한 것처럼 청구하는 상황을 법적 조제와 별도로 보아야 한다. 

Anti-Kickback Statute: federal health-care program에서 지불하는 항목·서비스의 referral 또는 business를 유도·보상하기 위해 알면서 고의로 금전적 가치 등을 주고받는 행위를 다룬다. 현금뿐 아니라 다른 이익도 관련될 수 있다. Safe harbor가 있으려면 그 조건을 충족해야 한다. 

Stark: physician의 financial relationship과 designated health services referral에 관한 별도 법이다. Outpatient prescription drugs도 해당 services에 포함되며, 적용 가능한 exception 여부를 확인한다. AKS와 동일한 intent 구조라고 외우지 않는다. 

OIG exclusion: 특정 사람·기관의 서비스·처방·주문 등에 대한 federal-program 지급이 제한될 수 있다. 이 문제는 DEA registration 유효성만 검사해서 해결되지 않는다. 과거 교육페이지의 고정 dollar penalties를 2026 최신 벌금으로 옮기지 않는다. 

Massachusetts 247 CMR 9.01(11)의 pharmacy referral 관련 remuneration 금지도 별도로 적용한다. 보험이 지불했다는 사실은 처방·제품·조제·청구의 모든 법적 요건이 충족됐다는 증거가 아니다.