해석 차이: 두 official texts를 확보했지만 적용 관계를 단일화하지 못한 경우이다. 양쪽 authority, 대상, trigger, 개정일을 남기고 공식 clarification·amendment·명시적 supersession가 있어야 닫는다.

접근 미완료: 문서가 존재하지만 readable full text를 확보하지 못한 경우이다. 링크를 찾았다는 사실만으로 내용 검증 완료로 바꾸지 않는다. 원본의 본문·표·각주를 확보하고 대조해야 닫는다.

미래 시행: 승인·공고됐지만 effective/implementation date가 아직 오지 않은 경우이다. 시험일과 실제 시행 상태가 확인되어야 current rule로 전환한다.

범위 경계: 상세 실무 전체가 아니라 기본 framework만 검토한 경우이다. 모든 specialty 예외가 검수됐다고 표시하지 않고, 시험 핵심 범위와 추가 전문 범위를 나눈다.