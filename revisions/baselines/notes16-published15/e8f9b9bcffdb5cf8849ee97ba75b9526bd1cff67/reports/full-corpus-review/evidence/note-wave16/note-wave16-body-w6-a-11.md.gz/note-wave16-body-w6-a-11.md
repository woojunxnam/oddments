Privacy Rule는 PHI의 이용·공개를 다루고, Security Rule는 covered entities와 business associates의 electronic PHI 보호에 적용된다. Breach Notification은 해당 침해에 대한 통지 체계이다. 종이 처방에 관한 비밀유지 문제가 곧 전자 보안 문제와 동일한 것은 아니지만, 여러 규칙이 같은 사건에 함께 적용될 수 있다. 

Security의 목표는 confidentiality, integrity, availability이다. 접근할 수 있는 사람을 제한하는 것뿐 아니라 정보의 정확성과 필요한 때 접근 가능한 상태도 중요하다. Administrative·physical·technical safeguards를 구별한다. 

학습 예시: 역할별 권한·직원 교육·위험평가는 관리 체계, 시설·기기 접근 통제는 물리적 보호, 인증·접근기록·전송보호는 기술적 보호와 연결해 이해한다. 하나의 좋은 비밀번호가 전체 보안 체계를 대신하지 않는다. 

현재 HHS 설명은 현행 rule와 별도의 proposed cybersecurity modifications를 구분한다. 제안된 요건을 이미 시행 중인 규정이라고 쓰지 않는다. MFA 같은 보호조치는 유용한 보안 설계가 될 수 있으나, 이 요약만으로 모든 약국에 동일한 제품·구현을 의무화한 법이라고 단정하지 않는다.