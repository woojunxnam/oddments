USPS Publication 52 §453에는 authorized mailer, 적격 prescription medicine, mail-back 등 경로가 있다. 따라서 ‘controlled substance는 모두 우편 금지’라는 요약은 부정확하다. 다만 주법·DEA·제품별 조건에 어긋나는 유통을 우편이라는 이유로 허용하지 않는다. 적법한 약국의 환자 배송 경로를 일반 개인의 자유로운 재분배와 동일시하지 않는다. 

Mailable controlled-substance 처방약의 내부 포장은 적절히 표시·봉인하고 prescription number와 dispensing pharmacy·practitioner 등의 이름·주소를 표시한다. 외부 포장은 내용물을 드러내는 표시가 없는 plain packaging이어야 한다. MA의 안정성·온도·배송 P&P도 함께 적용한다. 

Recall·제조사 withdrawal·dispensing error에 따른 지정된 return 경로와 ultimate-user unused drugs의 authorized mail-back disposal은 다르다. 환자에게서 제품이 돌아왔다고 그 약을 판매 재고로 돌릴 수 있는 것은 아니다. Domestic mail 규칙을 international mail에 그대로 확대하지 않는다.